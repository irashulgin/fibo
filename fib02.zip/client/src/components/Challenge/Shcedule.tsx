import   { useEffect, useState } from "react";
import ProgressChallenge from "./ProgressChallenge";
import { Box, Button  } from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers-pro";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { useAppDispatch  } from "../../hooks/redux";
import { addChallenge  } from "../../actions/challengeActions";
import useUser from "../../hooks/use-user";
import useChallenge from "../../hooks/use-challenge";
import { useNavigate } from "react-router-dom";
import DynamicInputDate from "../../commons/DynamicInputDate";

const Schedule = () => {
  const { challenge } = useChallenge();
  const [lastRegisterDate, setLastRegisterDate] = useState<string | null>(
    challenge.lastRegisterDate || null
  );
  const [startDate, setStartDate] = useState<string | null>(
    challenge.startDate || null
  );
  const [endDate, setEndDate] = useState<string | null>(
    challenge.endDate || null
  );

  const [roundname, setRoundname] = useState<string>(challenge.roundname || "");
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { user } = useUser();

  const [periodFields, setPeriodFields] = useState([]);
  const save = async () => {
    const newChallenge = {
      startDate,
      lastRegisterDate,
      roundname,
      creator: user.email,
      periodFields,
    };
    dispatch(addChallenge(newChallenge));
  };
  useEffect(() => {
    if (challenge.startDate) navigate("/creteria");
  }, [challenge.startDate, navigate]);

  // Callback function to handle changes in fields from DynamicInputDate component
  const handleFieldsChange = (fields: any) => {
    setPeriodFields(
      fields.map((field: { inputValue: string; inputDate: string }) => {
        return { roundName: field.inputValue, roundDate: field.inputDate };
      })
    );
  };
  return (
    <Box>
      <ProgressChallenge progress={45} />
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
          label="Start date"
          value={startDate}
          onChange={(newValue: string | null) =>
            !!newValue && setStartDate(newValue?.toLocaleString())
          }
        />
      </LocalizationProvider>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
          label="Last date to Register"
          value={lastRegisterDate}
          onChange={(newValue: string | null) =>
            !!newValue && setLastRegisterDate(newValue?.toLocaleString())
          }
        />
      </LocalizationProvider>

      <div>
        <DynamicInputDate onFieldsChange={handleFieldsChange} />
      </div>

      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
          label="End date"
          value={endDate}
          onChange={(newValue: string | null) =>
            newValue && setEndDate(newValue.toLocaleString())
          }
        />
      </LocalizationProvider>

      <Button onClick={save}>Next</Button>
    </Box>
  );
};
export default Schedule;
