import React from "react";
import ProgressChallenge from "./ProgressChallenge";
import { TextField } from "@mui/material";
import NextButton from "../../commons/Nextbutton";
import PrevButton from "../../commons/Prevbutton";
import { useAppDispatch } from "../../hooks/redux";
import { useNavigate } from "react-router-dom";
import { addChallenge } from "../../actions/challengeActions";
const ChallengeMethod = () => {
  const changeMoney = () => {};
  const changeFirstPlace = () => {};
  const changeSecondPlace = () => {};
  const changeThirdPlace = () => {};
  const price = 9;
  const firstPlace = 8;
  const secondPlace = 9;
  const thirdPlace = 8;
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const next = () => {
    dispatch(addChallenge({ price: 1, creator: "irena.ph@gmail.com" }));
    navigate("/");
  };

  return (
    <>
      <ProgressChallenge progress={60} />
      <TextField
        id="price"
        name="price"
        label="money price"
        variant="outlined"
        fullWidth
        margin="normal"
        value={price}
        onChange={changeMoney}
      />
      <TextField
        id="firstplace"
        name="firstplace"
        label="first place reward"
        variant="outlined"
        fullWidth
        margin="normal"
        value={firstPlace}
        multiline={true}
        onChange={changeFirstPlace}
      />{" "}
      <TextField
        id="secplace"
        name="secplace"
        label="second place reward"
        variant="outlined"
        fullWidth
        margin="normal"
        value={secondPlace}
        multiline={true}
        onChange={changeSecondPlace}
      />{" "}
      <TextField
        id="thirdplace"
        name="thirdplace"
        label="third place reward"
        variant="outlined"
        fullWidth
        margin="normal"
        value={thirdPlace}
        multiline={true}
        onChange={changeThirdPlace}
      />
      <PrevButton onClick={() => {}} />
      <NextButton onClick={next} />
    </>
  );
};
export default ChallengeMethod;
