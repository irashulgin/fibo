import ProgressChallenge from "./ProgressChallenge";
import { Box, IconButton, TextField } from "@mui/material";
import NextButton from "../../commons/Nextbutton";
import { useAppDispatch } from "../../hooks/redux";
import { saveChallenge } from "../../actions/challengeActions";
import { useFormik } from "formik";
import * as yup from "yup";
import useChallenge from "../../hooks/use-challenge";
import { FC } from "react";
const Rules: FC = () => {
  const dispatch = useAppDispatch();
  const uploadFile = (e: any) => {
    //const file = e.target.files[0];
    //todo
    // dispatch(save file(user.email,file));
  };

  const validationSchema = yup.object({
    title: yup.string().required("File title is  required"),
    description: yup.string().required("description is required"),
    rules: yup.string().required("rules is required"),
  });
  const { challenge } = useChallenge();
  const formik = useFormik({
    initialValues: {
      description: challenge.fileDescription || "",
      title: challenge.fileTitle || "",
      rules: challenge.rules || "",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      const newChallenge = values;
      dispatch(saveChallenge({ ...challenge, ...newChallenge }));
    },
  });

  return (
    <>
      <ProgressChallenge progress={100} />
      <form
        style={{
          alignItems: "center",
          display: "flex",
          gap: "10px",
          flexDirection: "column",
        }}
      >
        <TextField
          label="File title"
          variant="outlined"
          fullWidth
          margin="normal"
          name="title"
          value={formik.values.title}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.title && Boolean(formik.errors.title)}
          helperText={formik.touched.title && formik.errors.title}
        />
        <TextField
          label="description"
          variant="outlined"
          fullWidth
          margin="normal"
          name="description"
          value={formik.values.description}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={
            formik.touched.description && Boolean(formik.errors.description)
          }
          helperText={formik.touched.description && formik.errors.description}
        />

        <TextField
          label="Rules"
          variant="outlined"
          fullWidth
          margin="normal"
          name="rules"
          value={formik.values.rules}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.rules && Boolean(formik.errors.rules)}
          helperText={formik.touched.rules && formik.errors.rules}
        />
        <Box>
          <input
            accept="image/*"
            // className={classes.input}
            id="icon-button-photo"
            onChange={uploadFile}
            type="file"
          />
        </Box>
        <label htmlFor="icon-button-photo">
          <IconButton color="primary" component="span">
            Upload logo
          </IconButton>
        </label>

        <NextButton onClick={formik.handleSubmit} type="submit" />
      </form>
    </>
  );
};
export default Rules;
