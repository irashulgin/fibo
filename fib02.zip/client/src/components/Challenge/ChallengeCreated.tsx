import { FC } from "react";
import ThanksPage from "../../commons/ThanksPage";

const ChallengeCreated: FC = () => {
  return (
    <ThanksPage
      title={`Thank you\nfor creating new challenge`}
      text={`please wait for our team to check your 
      challenge before publishing`}
      footer={`we will let you know when it is confirmed`}
    />
  );
};
export default ChallengeCreated;
