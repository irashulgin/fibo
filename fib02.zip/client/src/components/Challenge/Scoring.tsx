import { FC, useEffect } from "react";
import ProgressChallenge from "./ProgressChallenge";
import { TextField } from "@mui/material";
import NextButton from "../../commons/Nextbutton";
import { useAppDispatch } from "../../hooks/redux";
import { useNavigate } from "react-router-dom";
import { addChallenge } from "../../actions/challengeActions";
import { useFormik } from "formik";
import * as yup from "yup";
import useChallenge from "../../hooks/use-challenge";
import styled from "@emotion/styled";

const StyledForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  align-items: center;
`;
const Scoring: FC = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const { challenge } = useChallenge();
  useEffect(() => {
    if (challenge.price) navigate("/schedule");
  }, [challenge.price, navigate]);

  const validationSchema = yup.object({
    price: yup.number().required("Price is  required"),
    firstplace: yup.string().required("first place is required"),
    secondplace: yup.string().required("second place is required"),
    thirdplace: yup.string().required("third place is required"),
  });

  const formik = useFormik({
    initialValues: {
      price: challenge.price || "",
      firstplace: challenge.firstPlace || "",
      secondplace: challenge.secondPlace || "",
      thirdplace: challenge.thirdPlace || "",
    },
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      dispatch(addChallenge(values));
    },
  });

  return (
    <>
      <ProgressChallenge progress={30} />
      <StyledForm>
        <TextField
          label="money price"
          variant="outlined"
          fullWidth
          margin="normal"
          name="price"
          value={formik.values.price}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.price && Boolean(formik.errors.price)}
          helperText={formik.touched.price && formik.errors.price}
        />
        <TextField
          label="first place reward"
          variant="outlined"
          fullWidth
          margin="normal"
          name="firstplace"
          value={formik.values.firstplace}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.firstplace && Boolean(formik.errors.firstplace)}
          helperText={formik.touched.firstplace && formik.errors.firstplace}
        />
        <TextField
          label="second place reward"
          variant="outlined"
          fullWidth
          margin="normal"
          name="secondplace"
          value={formik.values.secondplace}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={
            formik.touched.secondplace && Boolean(formik.errors.secondplace)
          }
          helperText={formik.touched.secondplace && formik.errors.secondplace}
        />
        <TextField
          label="third place reward"
          variant="outlined"
          fullWidth
          margin="normal"
          name="thirdplace"
          value={formik.values.thirdplace}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.thirdplace && Boolean(formik.errors.thirdplace)}
          helperText={formik.touched.thirdplace && formik.errors.thirdplace}
        />

        <NextButton onClick={formik.handleSubmit} type="submit" />
      </StyledForm>
    </>
  );
};
export default Scoring;
