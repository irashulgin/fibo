import { useEffect } from "react";
import { useAppDispatch } from "../../hooks/redux";
import { fetchChallenges } from "../../actions/challengesListActions";
import useChallenges from "../../hooks/use-challenges";
import { IChallenge } from "../../models/IChallenge";
import { Typography } from "@mui/material";
import useUser from "../../hooks/use-user";
import styled from "@emotion/styled";

const StyledDiv = styled.div`
  display: flex;
  flex-direction: column;
  background: #d7d7ed;
  margin: 1rem 0;
`;
const Challenges = () => {
  const { challengesList } = useChallenges();
  const { user } = useUser();
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(fetchChallenges({ searchTerm: "", email: user?.email }));
  }, [user.email, dispatch]);

  return (
    <>
      <Typography>Manage challenges</Typography>
      {challengesList?.map((item: IChallenge) => (
        <StyledDiv>
          <img src={item?.imageUrl} alt="" />
          <div>Description: {item?.description}</div>
          <div>Industry: {item?.industry}</div>
          <div>Profession: {item?.profession}</div>
          <div>Level: {item?.level}</div>
        </StyledDiv>
      ))}
    </>
  );
};
export default Challenges;
