import { Box, LinearProgress } from "@mui/material";

const ProgressChallenge = (props: any) => {
  const {progress} = props;
  console.log(progress);
let basic = "basic\n details";
  return (
    <div>
      <LinearProgress variant="determinate" value={progress} />
      <Box sx={{display:'flex'}}>
            <Box sx={{ whiteSpace: 'pre-line',flex: 1}}>{basic}</Box>
            <Box sx={{ whiteSpace: 'pre-line',flex: 1}}>{`scoring\nsystem`} </Box>
            <Box sx={{ whiteSpace: 'pre-line',flex: 1}}>schedule </Box>
            <Box sx={{ whiteSpace: 'pre-line',flex: 1}}>{`method\n& creteria`}</Box>
            <Box sx={{ whiteSpace: 'pre-line',flex: 1}}>{`files\n& rules`}</Box>
      </Box>
      <p>{`${progress}% Complete`}</p>
    </div>
  );
};

export default ProgressChallenge;
