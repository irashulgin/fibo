import { FC, useEffect } from "react";
import ProgressChallenge from "./ProgressChallenge";
import { TextField } from "@mui/material";
import NextButton from "../../commons/Nextbutton";
import { useAppDispatch } from "../../hooks/redux";
import { useNavigate } from "react-router-dom";
import { addChallenge } from "../../actions/challengeActions";
import { useFormik } from "formik";
import * as yup from "yup";
import useChallenge from "../../hooks/use-challenge";
const Creteria: FC = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { challenge } = useChallenge();

  const validationSchema = yup.object({
    primary: yup.string().required("primary discipline is  required"),
    secondary: yup.string().required("secondary discipline is  required"),
    profession: yup.string().required("profession is required"),
    level: yup.string().required("level type is required"),
    industry: yup.string().required("industry is required"),
    methodology: yup.string().required("methodology type is required"),
    tool: yup.string().required("tool name is required"),
    points: yup.string().required("experience points is required"),
  });

  useEffect(() => {
    if (challenge.industry) navigate("/rules");
  }, [challenge.industry, navigate]);

  const formik = useFormik({
    initialValues: {
      industry: challenge.industry || "",
      profession: challenge.profession || "",
      level: challenge.level || "",
      primary: challenge.primary || "",
      secondary: challenge.secondary || "",
      methodology: challenge.methodology || "",
      tool: challenge.tool || "",
      points: challenge.points || "",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      dispatch(addChallenge(values));
    },
  });

  return (
    <>
      <ProgressChallenge progress={70} />
      <form
        style={{
          alignItems: "center",
          display: "flex",
          gap: "10px",
          flexDirection: "column",
        }}
      >
        <TextField
          label="industry"
          variant="outlined"
          fullWidth
          margin="normal"
          name="industry"
          value={formik.values.industry}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.industry && Boolean(formik.errors.industry)}
        />
        <TextField
          label="profession/education"
          variant="outlined"
          fullWidth
          margin="normal"
          name="profession"
          value={formik.values.profession}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.profession && Boolean(formik.errors.profession)}
        />
        <TextField
          label="level type"
          variant="outlined"
          fullWidth
          margin="normal"
          name="level"
          value={formik.values.level}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.level && Boolean(formik.errors.level)}
          helperText={formik.touched.level && formik.errors.level}
        />
        <TextField
          label="Primary Discipline"
          variant="outlined"
          fullWidth
          margin="normal"
          name="primary"
          value={formik.values.primary}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.primary && Boolean(formik.errors.primary)}
          helperText={formik.touched.primary && formik.errors.primary}
        />
        <TextField
          label="Secondary Discipline"
          variant="outlined"
          fullWidth
          margin="normal"
          name="secondary"
          value={formik.values.secondary}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.secondary && Boolean(formik.errors.secondary)}
          helperText={formik.touched.secondary && formik.errors.secondary}
        />
        <TextField
          label="Methodology type"
          variant="outlined"
          fullWidth
          margin="normal"
          name="methodology"
          value={formik.values.methodology}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={
            formik.touched.methodology && Boolean(formik.errors.methodology)
          }
          helperText={formik.touched.methodology && formik.errors.methodology}
        />
        <TextField
          label="Tool name"
          variant="outlined"
          fullWidth
          margin="normal"
          name="tool"
          value={formik.values.tool}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.tool && Boolean(formik.errors.tool)}
          helperText={formik.touched.tool && formik.errors.tool}
        />
        <TextField
          label="Experience points"
          variant="outlined"
          fullWidth
          margin="normal"
          name="points"
          value={formik.values.points}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.points && Boolean(formik.errors.points)}
          helperText={formik.touched.points && formik.errors.points}
        />
        <NextButton onClick={formik.handleSubmit} type="submit" />
      </form>
    </>
  );
};
export default Creteria;
