import ProgressChallenge from "./ProgressChallenge";

const ChallengeContainer = ({ children }: any) => {
  return (
    <>
      <div>
        <ProgressChallenge status={1} />
      </div>
      <main>{children}</main>
    </>
  );
};

export default ChallengeContainer;
