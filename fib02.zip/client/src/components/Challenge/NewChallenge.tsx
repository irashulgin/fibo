import { TextField } from "@mui/material";
import { FC, useEffect, useState } from "react";
import { useAppDispatch } from "../../hooks/redux";
import ProgressChallenge from "./ProgressChallenge";
import { addChallenge } from "../../actions/challengeActions";
import { useNavigate } from "react-router-dom";
import NextButton from "../../commons/Nextbutton";
import useChallenge from "../../hooks/use-challenge";

const NewChallenge: FC = () => {
  const navigate = useNavigate();
  const [name, setName] = useState<string>("");
  const [creators, setCreators] = useState<string>("");
  const [sponsors, setSponsors] = useState<string>("");
  const [mentors, setMentors] = useState<string>("");
  const dispatch = useAppDispatch();
  const changeName = (e: any) => {
    setName(e.target.value);
  };
  const [description, setDescription] = useState<string>("");
  const changeDescription = (e: any) => {
    setDescription(e.target.value);
  };
  const challenge = useChallenge();

  useEffect(() => {
    if (!challenge.isLoading && challenge.challenge.creator)
      navigate("/scoring");
  }, [challenge, navigate]);

  const createChallenge = async () => {
    dispatch(
      addChallenge({ done: false, description, creator: "irena.ph@gmail.com" })
    );
  };
  return (
    <>
      <ProgressChallenge progress={10} />
      <TextField
        id="name"
        name="name"
        label="Challenge Name"
        variant="outlined"
        fullWidth
        margin="normal"
        value={name}
        onChange={changeName}
      />
      <TextField
        id="description"
        name="description"
        label="Describe the challenge"
        variant="outlined"
        fullWidth
        margin="normal"
        value={description}
        multiline={true}
        onChange={changeDescription}
      />
      <TextField
        id="creators"
        name="creators"
        label="creators"
        variant="outlined"
        fullWidth
        margin="normal"
        value={creators}
        multiline={true}
        onChange={(e) => setCreators(e.target.value)}
      />
      <TextField
        id="sponsors"
        name="sponsors"
        label="sponsors"
        variant="outlined"
        fullWidth
        margin="normal"
        value={sponsors}
        multiline={true}
        onChange={(e) => setSponsors(e.target.value)}
      />
      <TextField
        id="mentors"
        name="mentors"
        label="mentors"
        variant="outlined"
        fullWidth
        margin="normal"
        value={mentors}
        multiline={true}
        onChange={(e) => setMentors(e.target.value)}
      />

      {/* add cover photo ,creators, */}
      <NextButton onClick={createChallenge} />
    </>
  );
};

export default NewChallenge;
