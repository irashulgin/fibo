import { Box, Typography } from "@mui/material";
import { FC } from "react";
import { useNavigate } from "react-router-dom";
import useUser from "../hooks/use-user";
import { API_URL } from "../http";

const Manager: FC = () => {
  const { user } = useUser();

  const navigate = useNavigate();
  const manageChallenges = () => {};
  const createChallenge = () => {
    navigate("/new-challenge");
  };
  return (
    <>
      <Box sx={{ display: "flex", flexDirection: "column" }}>
        <Box sx={{ display: "flex" }}>
          <img alt='' src={`${API_URL}/${user.imageUrl}`} width="71px" />
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
            }}
          >
            <Typography>{user.name}</Typography>
            <Typography> {user.lastName}</Typography>
          </Box>
          <Box>{user.profession}</Box>
          <Box>{user.city}</Box>
        </Box>

        <Box sx={{ display: "flex", flexDirection: "column" }}>
          {/* <StyledWithGap> */}

          <Box>Add new user</Box>
          <Box onClick={createChallenge}>Create new challenge</Box>
          <Box>Manage users</Box>
          <Box onClick={manageChallenges}>Manage challenges</Box>

          {/* </StyledWithGap> */}
        </Box>
      </Box>
    </>
  );
};
export default Manager;
