import { SmallFib } from "../images/smallFib";
import { Typography } from "@mui/material";
import styled from "@emotion/styled";
import LeftMenu from "../commons/LeftMenu";
import useError from "../hooks/use-error";
import InfoMessage from "../commons/InfoMessage";
import { useLocation } from "react-router-dom";

const StyledHeader = styled.header`
  display: flex;
  justify-content: space-between;
`;

const StyledBox = styled.div`
  backgroundcolor: #f5f5f5;
  padding: 1rem;
  height: 100vh;
`;

const StyledMain = styled.main`
  height: 100vh;
`;
const StyledFib = styled.div`
  display: flex;
  alignitems: flex-end;
  gap: 0.5rem;
  justifycontent: flex-end;
`;

const Layout = ({ children }: any) => {
  const error = useError();
  const location = useLocation();
  const showMenu = !['/login','/signup','/forgot-password'].includes(location.pathname);
  return (
    <StyledBox>
      {/* <TopBar /> */}

      <StyledHeader>
        {/* <Box>
          {" "}
          <AccountCircleIcon />
        </Box> */}
        {showMenu && <LeftMenu />}
        <StyledFib>
          <SmallFib />
          <Typography sx={{ height: 31 }}>Fibonacci</Typography>
        </StyledFib>
      </StyledHeader>

      <StyledMain>{children}</StyledMain>

      {/* <footer>
        <p>&copy; {new Date().getFullYear()} Footer</p>
      </footer> */}
      {error.successMessage && (
        <InfoMessage message={error.successMessage} isError={false} />
      )}
      {error.errorMessage && (
        <InfoMessage message={error.errorMessage} isError={true} />
      )}
    </StyledBox>
  );
};

export default Layout;
