import { FC, useState } from "react";
import { GlobalStyledBox } from "../commons/GlobalStyle";
import { Button, TextField } from "@mui/material";
import { useAppDispatch } from "../hooks/redux";
import { inviteUser } from "../actions/userActions";
import InfoMessage from "../commons/InfoMessage";
import { useFormik } from "formik";
import * as yup from "yup";
import useFormWithValidation from "../hooks/use-form";

const ReferFriend: FC = () => {
  const dispatch = useAppDispatch();
    
  // const [infoMsg, setInfoMsg] = useState<string>("");
  const [error, setError] = useState<string>("");
  const validationSchema = yup.object({
    email: yup.string().email("Invalid email").required("Email is required"),
  });

//   const formik = useFormik({
//     initialValues: {
//       email: "",
//       note: "",
//     },
//     validationSchema: validationSchema,
//     onSubmit: async (values) => {
//       sendReferral(values);
//     },
//   });
  const onSubmit = async (values:any) => {
    sendReferral(values);
  }
  const formik = useFormWithValidation({},validationSchema,onSubmit)
  const sendReferral = async (values: { email: string; note: string, userEmail:string }) => {
    const { email, note, userEmail } = values;
    try {
      // const invited = 
      await dispatch(inviteUser(email, userEmail));
      // if (invited) {
      //   //todo send note
      //   setInfoMsg(invited);
      // }
    } catch (e: any) {
      setError(e.message);
    }
  };
  return (
    <GlobalStyledBox>
      <form onSubmit={formik.handleSubmit}>
        <TextField
          label="Email"
          variant="outlined"
          fullWidth
          margin="normal"
          name="email"
          value={formik.values.email}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.email && Boolean(formik.errors.email)}
        //   helperText={formik.touched.email && formik.errors.email}
        />
        <TextField
          label="note"
          variant="outlined"
          fullWidth
          margin="normal"
          name="note"
          value={formik.values.note}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.note && Boolean(formik.errors.note)}
        //   helperText={formik.touched.note && formik.errors.note}
        />

        <Button type="submit">Send a refferal link</Button>
        {/* {infoMsg && <InfoMessage message={infoMsg} />} */}
        {error ? <>{error}</> : <></>}
      </form>
    </GlobalStyledBox>
  );
};

export default ReferFriend;
