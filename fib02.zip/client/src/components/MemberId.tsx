import styled from "@emotion/styled";
import { FC } from "react";
import { Icon } from "../images/background";

import useAuth from "../hooks/use-auth";
const StyledDiv = styled.div``;

const MemberId: FC = () => {
  const auth = useAuth();
  const user = auth.userInfo;
  return (
    <StyledDiv>
      <Icon />
    </StyledDiv>
  );
};
export default MemberId;
