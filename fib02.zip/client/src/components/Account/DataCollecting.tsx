import { TextField } from "@mui/material";
import NextButton from "../../commons/Nextbutton";
import { useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as yup from "yup";
import { useAppDispatch } from "../../hooks/redux";
import { collectData } from "../../actions/userActions";

import useUser from "../../hooks/use-user";
import { StyledWithGap } from "../../commons/GlobalStyle";
import { FC, useEffect } from "react";
import styled from "@emotion/styled";

const validationSchema = yup.object({
  city: yup.string().required("City is required"),
  profession: yup.string().required("Profession is required"),
  phone: yup.string().required("Phone number is required"),
  institute: yup.string().required("Institute is required"),
  currentWork: yup.string().required("Current work is required"),
  birthDate: yup.date().required("Birth date is required"),
});

const CenteredForm = styled.form`
  align-items: "center";
`;
const DataCollecting: FC = () => {
  const { user } = useUser();

  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (user?.city) navigate("/account-info");
  }, [user, navigate]);

  const formik = useFormik({
    initialValues: {
      city: user?.city || "",
      profession: user?.profession || "",
      phone: user.phone || null,
      birthDate: user.birthDate || "",
      institute: user.institute || "",
      currentWork: user.currentWork || "",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      dispatch(collectData({ ...values, email: user.email }));
    },
  });

  return (
    <CenteredForm>
      <h2>First we need a few details</h2>

      <StyledWithGap>
        <TextField
          label="City"
          variant="outlined"
          fullWidth
          margin="normal"
          name="city"
          value={formik.values.city}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.city && Boolean(formik.errors.city)}
          helperText={formik.touched.city && formik.errors.city}
        />
      </StyledWithGap>
      <TextField
        label="Profession"
        variant="outlined"
        fullWidth
        margin="normal"
        name="profession"
        value={formik.values.profession}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.profession && Boolean(formik.errors.profession)}
        helperText={formik.touched.profession && formik.errors.profession}
      />

      <TextField
        label="Phone Number"
        variant="outlined"
        fullWidth
        margin="normal"
        name="phone"
        value={formik.values.phone}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.phone && Boolean(formik.errors.phone)}
        helperText={formik.touched.phone && formik.errors.phone}
      />

      <TextField
        id="date"
        label="Birth Date"
        type="date"
        name="birthDate"
        variant="outlined"
        fullWidth
        InputLabelProps={{
          shrink: true,
        }}
        value={formik.values.birthDate}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.birthDate && Boolean(formik.errors.birthDate)}
        helperText={formik.touched.birthDate && formik.errors.birthDate}
      />

      <TextField
        label="Current work place"
        variant="outlined"
        fullWidth
        margin="normal"
        name="currentWork"
        value={formik.values.currentWork}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.currentWork && Boolean(formik.errors.currentWork)}
        helperText={formik.touched.currentWork && formik.errors.currentWork}
      />
      <TextField
        label="Institute"
        variant="outlined"
        fullWidth
        margin="normal"
        name="institute"
        value={formik.values.institute}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.institute && Boolean(formik.errors.institute)}
        helperText={formik.touched.institute && formik.errors.institute}
      />
      <NextButton onClick={formik.handleSubmit} type="submit" />
    </CenteredForm>
  );
};
export default DataCollecting;
