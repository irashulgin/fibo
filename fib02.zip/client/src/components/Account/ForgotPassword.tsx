import { useState } from "react";
import { useAppDispatch } from "../../hooks/redux";
import { forgotUserPassword } from "../../actions/authActions";
import { Box, Button, TextField } from "@mui/material";
import { validateEmail } from "../../commons/helper";
import styled from "@emotion/styled";
import { updateErrorMessage } from "../../actions/errorActions";

const StyledForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  align-items: center;
`;

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  // const error = useError();
  const dispatch = useAppDispatch();

  const handleInputChange = (e: any) => {
    const { value } = e.target;
    setEmail(value);
  };

  const validateUserEmail = () => {
    const isValidEmail = validateEmail(email);
    isValidEmail
      ? setEmail(email)
      : dispatch(updateErrorMessage("not valid email"));
    return isValidEmail;
  };

  const handleReset = () => {
    if (validateUserEmail()) {
      dispatch(forgotUserPassword(email));
      //
    } else {
      dispatch(updateErrorMessage("not valid email"));
    }
  };

  return (
    <Box>
      <StyledForm>
        <h2>Reset Password</h2>
        <div>
          <TextField
            type="email"
            label="Email"
            name="email"
            value={email}
            onChange={handleInputChange}
          />
        </div>

        <Button variant="contained" color="primary" onClick={handleReset}>
          Reset Password
        </Button>
      </StyledForm>
      {/* {error} */}
    </Box>
  );
};

export default ForgotPassword;
