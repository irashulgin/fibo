import { FC, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useAppDispatch } from "../../hooks/redux";
import { resetPassword } from "../../actions/authActions";
import { setError } from "../../store/reducers/AuthSlice";
import { Box, Button, TextField } from "@mui/material";
import { validatePassword } from "../../commons/helper";

import styled from "@emotion/styled";
import { updateErrorMessage } from "../../actions/errorActions";
import useError from "../../hooks/use-error";

const StyledForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  align-items: center;
`;

const UpdatePassword: FC = () => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const { token } = useParams();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const [passwordError, setPasswordError] = useState("");
  const error = useError();

  useEffect(() => {
    if (error.successMessage) {
      navigate("/login");
    }
  }, [error.successMessage, navigate]);

  const handleInputChange = (e: any) => {
    const { name, value } = e.target;
    if (name === "password") {
      setPassword(value);
    } else if (name === "confirmPassword") {
      setConfirmPassword(value);
    }
  };

  const handleValidatePassword = () => {
    if (validatePassword(password)) {
      setPasswordError("");
    } else {
      setPasswordError("Please check your password");
    }
  };
  const handleResetPassword = () => {
    try {
      if (token) {
        dispatch(resetPassword(token, password));
      } else {
        dispatch(updateErrorMessage("Please click on the link in your email"));
      }
    } catch (e: any) {
      dispatch(updateErrorMessage(e.response.data.message));
      setError(e.response.data.message);
    }
  };

  return (
    <Box>
      <h2>Update Password</h2>
      <StyledForm>
        <div>
          <TextField
            type="password"
            label="New Password"
            name="password"
            value={password}
            onChange={handleInputChange}
            onBlur={handleValidatePassword}
            error={!!passwordError}
            helperText={passwordError}
            onFocus={() => setPasswordError("")}
          />
        </div>
        <div>
          <TextField
            type="password"
            label="Confirm Password"
            name="confirmPassword"
            value={confirmPassword}
            onChange={handleInputChange}
          />
        </div>
        <Button
          variant="contained"
          color="primary"
          onClick={handleResetPassword}
          disabled={!!passwordError || password !== confirmPassword}
        >
          Update Password
        </Button>
        <div>
          {password !== confirmPassword ? <>Passwords don't match</> : <></>}
        </div>
      </StyledForm>
    </Box>
  );
};

export default UpdatePassword;
