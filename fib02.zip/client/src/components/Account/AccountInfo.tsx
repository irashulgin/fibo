import { IconButton, TextField, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import styled from "@emotion/styled";
import NextButton from "../../commons/Nextbutton";
import { useNavigate } from "react-router-dom";
import { useAppDispatch } from "../../hooks/redux";
import { collectData, saveFile } from "../../actions/userActions";
import { updateUserData } from "../../actions/userActions";
import useUser from "../../hooks/use-user";
import useError from "../../hooks/use-error";

const StyledDiv = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;
const AccountInfo: React.FC = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { user } = useUser();
  const [about, setAbout] = useState<string>(user?.about || "");
  const [interests, setInterests] = useState<string>(user?.interests || "");

  const error = useError();

  useEffect(() => {
    if (user?.interests && error.errorMessage === "") navigate("/signup-done");
  }, [user, error.errorMessage, navigate]);

  const uploadFile = (e: any) => {
    const file = e.target.files[0];
    dispatch(saveFile(user.email, file));
  };

  const onClick = () => {
    const data = {
      interests,
      about,
      email: user.email,
      imageUrl: user.imageUrl,
    };
    dispatch(updateUserData(data));
    dispatch(collectData(data));
  };
  return (
    <StyledDiv>
      <Typography variant="body1">Lets get to know each other</Typography>
      <TextField
        placeholder="What are your interests?"
        multiline
        minRows={4}
        maxRows={10}
        value={interests}
        onChange={(e) => setInterests(e.target.value)}
      />
      <TextField
        placeholder="Tell us a little bit about yourself"
        multiline
        minRows={4}
        maxRows={3}
        value={about}
        onChange={(e) => setAbout(e.target.value)}
      />
      <input
        accept="image/*"
        // className={classes.input}
        id="icon-button-photo"
        onChange={uploadFile}
        type="file"
      />
      <label htmlFor="icon-button-photo">
        <IconButton color="primary" component="span">
          upload file
        </IconButton>
      </label>
      <NextButton onClick={onClick} />
    </StyledDiv>
  );
};
export default AccountInfo;
