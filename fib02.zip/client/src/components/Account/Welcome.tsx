import {  Typography } from "@mui/material";
import { SVGFib } from "../../images/fib";
import React from "react";
import NextButton from "../../commons/Nextbutton";
import { useNavigate } from "react-router-dom";
import {GlobalStyledBox} from "../../commons/GlobalStyle";
 
const Welcome = () => {
  const navigate = useNavigate();
  const multiLineText = `Our vision is to enhance the unity of economic value and societal value – with the help of data science, technology, and social vision.

    We believe that it's time to draw our imagination of a better world on a new canvas, a canvas that shares the voice of many human beings who contribute every day to humanity.
    
    Scientists, tech people, artists.`;
  const lines = multiLineText.split("\n");
  const nextOnClick = () => {
    console.log("next clicked on welcome page");
    navigate("/signup");
    // navigate("/reference");
  };

  return (
    <GlobalStyledBox>
      <Typography>Welcome to Fibonacci</Typography>
      <SVGFib />
      <Typography variant="body1" paragraph={true}>
        {lines.map((line, index) => (
          <React.Fragment key={index}>
            {line}
            <br />
          </React.Fragment>
        ))}
      </Typography>

      <Typography variant="subtitle1">
        Ready to be part of our community?
      </Typography>
      <NextButton onClick={nextOnClick} />
    </GlobalStyledBox>
  );
};
export default Welcome;
