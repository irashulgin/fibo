import { TextField } from "@mui/material";
import { FC, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { loginUser } from "../../actions/authActions";
import { useAppDispatch } from "../../hooks/redux";
import useAuth from "../../hooks/use-auth";
import NextButton from "../../commons/Nextbutton";
import { useFormik } from "formik";
import * as yup from "yup";

import styled from "@emotion/styled";
import useUser from "../../hooks/use-user";

const DivForgot = styled.div`
  cursor: pointer;
  color: #1976d2;
  margin: 1rem 0;
`;
const StyledForm = styled.form`
align-items: center,
display: flex,
gap: 1rem,
flex-direction: column`;

const Login: FC = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const forgotPassword = () => {
    navigate("/forgot-password");
  };
  const auth = useAuth();
  const user = useUser();

  const validationSchema = yup.object({
    email: yup.string().email("Invalid email").required("Email is required"),
    password: yup
      .string()
      .required("Password is required")
      .min(8, "Password must be at least 8 characters"),
    // .matches(
    //   /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/,
    //   "Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character"
    // ),//todo
  });
 

  useEffect(() => {
    debugger;
    if (auth.isAuth && user?.user?.email) {
      navigate("/user-profile");
    }
  }, [auth.isAuth]);

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      dispatch(loginUser(values.email, values.password));
    },
  });

  return (
    <StyledForm>
      <TextField
        label="Email"
        variant="outlined"
        fullWidth
        margin="normal"
        name="email"
        value={formik.values.email}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.email && Boolean(formik.errors.email)}
        helperText={formik.touched.email && formik.errors.email}
      />
      <TextField
        label="Password"
        type="password"
        fullWidth
        margin="normal"
        name="password"
        value={formik.values.password}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.password && Boolean(formik.errors.password)}
        helperText={formik.touched.password && formik.errors.password}
      />
      <DivForgot onClick={forgotPassword}>Forgot password?</DivForgot>

      {/* <Button type="submit" onClick={formik.handleSubmit}> */}

      {/* <FormDialog
        email={email}
        setEmail={setEmail}
        handleReset={forgotPassword}
        message={error}
      ></FormDialog> */}
      <NextButton onClick={formik.handleSubmit} type="submit" />
    </StyledForm>
  );
};
export default Login;
