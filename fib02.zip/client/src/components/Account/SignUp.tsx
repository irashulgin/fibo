import { TextField } from "@mui/material";
import NextButton from "../../commons/Nextbutton";
import { useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as yup from "yup";
import { registerUser } from "../../actions/authActions";
import { useAppDispatch } from "../../hooks/redux";
import { StyledWithGap } from "../../commons/GlobalStyle";
import useUser from "../../hooks/use-user";
import { FC, useEffect } from "react";
import styled from "@emotion/styled";

const validationSchema = yup.object({
  lastName: yup.string().required("Name is required"),
  name: yup.string().required("Name is required"),
  email: yup.string().email("Invalid email").required("Email is required"),

  password: yup
    .string()
    .required("Password is required")
    .min(8, "Password must be at least 8 characters")
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/,
      "Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character"
    ),
  confirm: yup
    .string()
    .oneOf([yup.ref("password")], "Passwords must match")
    .required("Confirm Password is required"),
});

const CenteredForm = styled.form`
  align-items: "center";
`;

const SignUp: FC = () => {
  const { user } = useUser();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (user.email) {
      navigate("/data-collecting");
    }
  }, [user, navigate]);

  const formik = useFormik({
    initialValues: {
      name: user?.name || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
      password: user?.password || "",
      confirm: user?.password || "",
      role: user?.role || "",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      values.role = "User";

      const { confirm, ...newObj } = values;

      dispatch(registerUser(newObj));
    },
  });

  return (
    <CenteredForm>
      <h2>First we need a few details</h2>

      <StyledWithGap>
        <TextField
          id="name"
          name="name"
          label="Name"
          variant="outlined"
          fullWidth
          margin="normal"
          value={formik.values.name}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.name && Boolean(formik.errors.name)}
          helperText={formik.touched.name && formik.errors.name}
        />
        <TextField
          label="Last Name"
          variant="outlined"
          name="lastName"
          fullWidth
          margin="normal"
          value={formik.values.lastName}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.lastName && Boolean(formik.errors.lastName)}
          helperText={formik.touched.lastName && formik.errors.lastName}
        />
      </StyledWithGap>

      <TextField
        label="Email"
        variant="outlined"
        fullWidth
        margin="normal"
        name="email"
        value={formik.values.email}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.email && Boolean(formik.errors.email)}
        helperText={formik.touched.email && formik.errors.email}
      />

      <TextField
        label="Password"
        type="password"
        fullWidth
        margin="normal"
        name="password"
        value={formik.values.password}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.password && Boolean(formik.errors.password)}
        helperText={formik.touched.password && formik.errors.password}
      />
      <TextField
        type="password"
        label="Confirm Password"
        name="confirm"
        fullWidth
        value={formik.values.confirm}
        error={formik.touched.confirm && Boolean(formik.errors.confirm)}
        helperText={formik.touched.confirm && formik.errors.confirm}
        onChange={formik.handleChange}
      />

      <NextButton onClick={formik.handleSubmit} type="submit" />
    </CenteredForm>
  );
};
export default SignUp;
