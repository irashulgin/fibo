import styled from "@emotion/styled";
import { Typography } from "@mui/material";
import { FC } from "react"; 
import {GlobalStyledBox} from "../../commons/GlobalStyle";

 
const StyledText = styled.p`
    border: 1px solid #fff;

`;
const SignUpDone:FC = () => {
// const user = useUser();
    return (
        <GlobalStyledBox>
            <Typography>
             Thanks for signing up!
            </Typography>
            <StyledText>
            Our team will check your registration soon...
            </StyledText>
            <Typography>we will let you know when your profile is ready</Typography>
        </GlobalStyledBox>
    )

}
export default SignUpDone;