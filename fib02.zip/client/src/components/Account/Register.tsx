import { TextField } from "@mui/material";
import NextButton from "../../commons/Nextbutton";
import { useNavigate } from "react-router-dom";

import { useFormik } from "formik";
import * as yup from "yup";

import { registerUser } from "../../actions/authActions";
import { useAppDispatch } from "../../hooks/redux";
import useAuth from "../../hooks/use-auth";
import { StyledWithGap } from "../../commons/GlobalStyle";
import { FC, useEffect } from "react";
import styled from "@emotion/styled";

const validationSchema = yup.object({
  // name: yup.string().required("Name is required"),
  // lastName: yup.string().required("Last name is required"),
  // state: yup.string().required("State is required"),
  // city: yup.string().required("City is required"),
  // email: yup.string().email("Invalid email").required("Email is required"),
  // id: yup.number().required("ID is required"),
  // profession: yup.string().required("Profession is required"),
  // // reference: yup.string().required("Reference number is required"),
  // phone: yup.string().required("Phone number is required"),
  // password: yup
  //   .string()
  //   .required("Password is required")
  //   .min(8, "Password must be at least 8 characters")
  //   .matches(
  //     /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/,
  //     "Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character"
  //   ),
});

const CenteredForm = styled.form`
  align-items: "center";
`;
const Register: FC = () => {
  const auth = useAuth();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (auth.isAuth) {
      navigate("/account-info");
    }
  }, [navigate, auth.isAuth]);

  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      lastName: "",
      _id: "",
      state: "",
      city: "",
      profession: "",
      reference: -1,
      phone: null,
      password: "",
      isActivated: true,
      role: "",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      values.reference = Math.random() * Math.max();
      values.role = "User";
      dispatch(registerUser(values));
    },
  });

  return (
    <CenteredForm>
      <h2>First we need a few details</h2>

      <StyledWithGap>
        <TextField
          id="name"
          name="name"
          label="Name"
          variant="outlined"
          fullWidth
          margin="normal"
          value={formik.values.name}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.name && Boolean(formik.errors.name)}
          helperText={formik.touched.name && formik.errors.name}
        />
        <TextField
          label="Last Name"
          variant="outlined"
          name="lastName"
          fullWidth
          margin="normal"
          value={formik.values.lastName}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.lastName && Boolean(formik.errors.lastName)}
          helperText={formik.touched.lastName && formik.errors.lastName}
        />
      </StyledWithGap>
      {/* <TextField
        label="ID Number"
        variant="outlined"
        fullWidth
        margin="normal"
        name="_id"
        value={formik.values._id}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched._id && Boolean(formik.errors._id)}
        helperText={formik.touched._id && formik.errors._id}
      /> */}
      <StyledWithGap>
        <TextField
          label="State"
          variant="outlined"
          fullWidth
          margin="normal"
          name="state"
          value={formik.values.state}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.state && Boolean(formik.errors.state)}
          helperText={formik.touched.state && formik.errors.state}
        />
        <TextField
          label="City"
          variant="outlined"
          fullWidth
          margin="normal"
          name="city"
          value={formik.values.city}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.city && Boolean(formik.errors.city)}
          helperText={formik.touched.city && formik.errors.city}
        />
      </StyledWithGap>
      <TextField
        label="Profession"
        variant="outlined"
        fullWidth
        margin="normal"
        name="profession"
        value={formik.values.profession}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.profession && Boolean(formik.errors.profession)}
        helperText={formik.touched.profession && formik.errors.profession}
      />
      <TextField
        label="Email"
        variant="outlined"
        fullWidth
        margin="normal"
        name="email"
        value={formik.values.email}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.email && Boolean(formik.errors.email)}
        helperText={formik.touched.email && formik.errors.email}
      />
      <TextField
        label="Phone Number"
        variant="outlined"
        fullWidth
        margin="normal"
        name="phone"
        value={formik.values.phone}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.phone && Boolean(formik.errors.phone)}
        helperText={formik.touched.phone && formik.errors.phone}
      />
      {/* <TextField
        label="Referral Number"
        variant="outlined"
        fullWidth
        margin="normal"
        name="phone"
        value={formik.values.phone}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.phone && Boolean(formik.errors.phone)}
        helperText={formik.touched.phone && formik.errors.phone}
      /> */}

      {/* <FormHelperText id="my-helper-text">We'll never share your email.</FormHelperText> */}
      <TextField
        label="Password"
        type="password"
        fullWidth
        margin="normal"
        name="password"
        value={formik.values.password}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        error={formik.touched.password && Boolean(formik.errors.password)}
        helperText={formik.touched.password && formik.errors.password}
      />
      <>{auth.error ? <>{auth.error}</> : <></>}</>
      <NextButton onClick={formik.handleSubmit} type="submit" />
    </CenteredForm>
  );
};
export default Register;
