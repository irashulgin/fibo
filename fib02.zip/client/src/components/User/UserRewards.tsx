import styled from "@emotion/styled";
import useUser from "../../hooks/use-user";
import { Typography } from "@mui/material";

const SectionInterest = styled.div`
  display: flex;
`;

const UserRewards = () => {
  const { user } = useUser();
  return (
    <div style={{ display: "flex" }}>
      <SectionInterest>
        <Typography>Rewards:</Typography>
        {`${user?.rewards}`}
      </SectionInterest>
    </div>
  );
};

export default UserRewards;
