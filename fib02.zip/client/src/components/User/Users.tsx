import { Suspense, useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../hooks/redux";
import { Button, Grid, TextField } from "@mui/material";
import useUsers from "../../hooks/use-users";
import { fetchUsers } from "../../actions/usersActions";
import { inviteUser } from "../../actions/userActions";
import useUser from "../../hooks/use-user";

const Users = () => {
  const dispatch = useAppDispatch();
  const [searchTerm, setSearchTerm] = useState("");
  const [email, setEmail] = useState<string>("");
  const { userList, error, isLoading } = useUsers();
  const [errors, setErrors] = useState<Error | null>(null);
  const msg = useAppSelector((state) => state.error.successMessage);
  const { user } = useUser();

  useEffect(() => {
    dispatch(fetchUsers(""));
  }, [dispatch]);
  const invite = () => {
    if (email) {debugger;
      dispatch(inviteUser(email, user.email));
    } else {
      debugger;
      setErrors(new Error("Please type an email"));
    }
  };

  useEffect(() => {
    // Fetch users from the backend API based on search criteria
    // Update the 'users' state with the fetched data
  }, [searchTerm]);

  const handleSearch = () => {
    // Trigger the search by updating the 'searchTerm' state
    dispatch(fetchUsers(searchTerm));
  };
  if (isLoading) {
    return <>Loading...</>;
  }
  if (error) {
    return <> {error}</>;
  }

  return (
    <>
      <>{msg}</>
      <Suspense fallback={<p>Loading users data...</p>}></Suspense>
      <h1>User Management</h1>
      {/* {users?.map(item=>(
           <Box key={item._id}> <Box>{item.email}</Box></Box>
        ))} */}
      <div>
        <TextField
          label="Search"
          variant="outlined"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <Button variant="contained" onClick={handleSearch}>
          Search
        </Button>

        <Grid container spacing={2}>
          {userList.map((user) => (
            <Grid item key={user.id} xs={12} sm={6} md={4}>
              {/* Render user details */}
              {/* Adjust this part based on your user data structure */}
              <div>
                <h3>{user.name}</h3>
                <p>Email: {user.email}</p>
              </div>
            </Grid>
          ))}
        </Grid>

        <TextField
          id="email"
          name="email"
          label="Email"
          variant="outlined"
          fullWidth
          margin="normal"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <Button onClick={invite}> Invite</Button>
        <>{errors}</>
        {/* <ErrorDisplay error={errors} onClose={handleCloseError} /> */}
        {/* {infoMsg && <InfoMessage message={infoMsg} />} */}
      </div>{" "}
    </>
  );
};
export default Users;
