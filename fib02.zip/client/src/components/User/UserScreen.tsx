import { FC } from "react";
import { useNavigate } from "react-router-dom";
import { Box, Button } from "@mui/material";
import { useAppDispatch } from "../../hooks/redux";
import { logout } from "../../actions/authActions";
import useAuth from "../../hooks/use-auth";

const UserScreen: FC = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const add = () => {
    navigate("/new-challenge");
  };
  const logoutUser = async () => {
    try {
      dispatch(logout());
      // navigate("/login");
    } catch (e) { 
      console.log(e);
    }
  };
  const auth  = useAuth();
  
  if (!auth.isAuth) {
    debugger;
    navigate("/login");
  }

  return (
    <Box>
      Email:{auth.userInfo.email}
      <Button onClick={add}>add challenge</Button>
      <Button onClick={logoutUser}>Logout</Button>
    </Box>
  );
};
export default UserScreen;
