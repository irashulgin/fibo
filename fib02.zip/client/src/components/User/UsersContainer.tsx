// import { SVGImage } from "../images/image";
import Users from "./Users";

const UsersContainer = () => {
  return (
    <>
      {/* <SVGImage/> */}
      <Users />
    </>
  );
};
export default UsersContainer;
