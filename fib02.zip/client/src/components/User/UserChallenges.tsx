import styled from "@emotion/styled";
import useUser from "../../hooks/use-user";
import { Typography } from "@mui/material";

const SectionInterest = styled.div`
  display: flex;
`;

const UserChallenges = () => {
  const { user } = useUser();
  return (
    <div style={{ display: "flex" }}>
      <SectionInterest>
        <Typography>Challenges:</Typography>
        {`${user?.challenges}`}
      </SectionInterest>
    </div>
  );
};

export default UserChallenges;
