import { Box, Button, TextField } from "@mui/material";
import { FC } from "react";
import useUser from "../../hooks/use-user";
import styled from "@emotion/styled";
import { API_URL } from "../../http";
import { GlobalStyledBox } from "../../commons/GlobalStyle";
import TabsMenu from "../../commons/TabsMenu";
import UserAbout from "./UserAbout";
import UserRewards from "./UserRewards";
import UserChallenges from "./UserChallenges";
import Footer from "../../commons/Footer";
import moment from "moment";

const TopMenu = styled.div`
  width: 100%;
  margin-bottom: 1rem;
`;
const StyledTopDiv = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 1rem;
`;

const SlyledBox = styled.div`
  margin: 0.5rem 0;
`;

const UserProfile: FC = () => {
  const { user } = useUser();
  const names = ["About", "Rewards", "Challenges"];
  const components = [<UserAbout />, <UserRewards />, <UserChallenges />];

  return (
    <GlobalStyledBox>
      <StyledTopDiv>
        <img alt="" src={`${API_URL}/${user.imageUrl}`} width="200px" />
        <SlyledBox>{user.name}</SlyledBox>
        <SlyledBox> {user.lastName}</SlyledBox>
        <SlyledBox>{user.profession}</SlyledBox>
        <SlyledBox>{user.city}</SlyledBox>
        <SlyledBox>
          {moment(user.birthDate).utc().format("YYYY-MM-DD")}

          {/* <TextField
            id="date"
            label="Select Date"
            type="date"
            value={user.birthDate}
            InputLabelProps={{
              shrink: true,
            }}
          /> */}
        </SlyledBox>
        <SlyledBox>{user.institute}</SlyledBox>
        <SlyledBox>{user.currentWork}</SlyledBox>
      </StyledTopDiv>
      <TopMenu>
        <TabsMenu names={names} components={components} />
      </TopMenu>
      <Footer />
      {/* reffered by */}
      {/* member since  */}
      {/* reffered  */}
      {user.role === "Admin" ? <Button>Invite</Button> : <></>}
    </GlobalStyledBox>
  );
};
export default UserProfile;
