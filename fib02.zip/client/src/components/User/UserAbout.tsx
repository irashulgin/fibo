import styled from "@emotion/styled";
import { FC } from "react";
import useUser from "../../hooks/use-user";
import { Typography } from "@mui/material";

const SectionInterest = styled.div`
  display: flex;
`;
const StyledDiv = styled.div`
  display: flex;
  flex-direction: column
`;

const UserAbout: FC = () => {
  const { user } = useUser();
  return (
    <StyledDiv>
      <SectionInterest>
        <Typography>Interests:</Typography>
        {`${user?.interests}`}
      </SectionInterest>
      <SectionInterest>
        <Typography>About:</Typography>
        {`${user?.about}`}
      </SectionInterest>
    </StyledDiv>
  );
};

export default UserAbout;
