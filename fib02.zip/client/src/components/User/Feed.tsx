import { FC } from "react";

const Feed: FC = () => {
  return <>some news ... todo</>;
};
export default Feed;
