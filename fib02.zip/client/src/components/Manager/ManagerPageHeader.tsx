import { Button, Typography } from "@mui/material";
import { FC } from "react";
import useChallenge from "../../hooks/use-challenge";

const ManagerPageHeader: FC = () => {
  const { challenge } = useChallenge();
  return (
    <>
      <img src={challenge.imageUrl} alt=''/>
      <Typography>{`Hosted by : ${challenge.creator}`}</Typography>
      <Button>Manage Challenge</Button>
    </>
  );
};
export default ManagerPageHeader;
