import { FC } from "react";
import useChallenge from "../../hooks/use-challenge";
import { Typography } from "@mui/material";

const OverviewChallenge: FC = () => {
  const { challenge } = useChallenge();
  return (
    <>
      <Typography>About</Typography>
      <Typography>Industry</Typography>
      <Typography>Profession/Education</Typography>
      <Typography>Prizes&Rewards</Typography>
      <>Prize money:{}</>
      <>1st place:</>
      <>2nd place:</>
      <>3rs place:</>
      <>All solvers: </>
      <Typography>Level Type</Typography>
      <Typography>Discipline</Typography>
      <Typography>Methodology Type</Typography>
    </>
  );
};
export default OverviewChallenge;
