import TabsMenu from "../../commons/TabsMenu";
// import useChallenge from "../../hooks/use-challenge";
import ManagerPageHeader from "./ManagerPageHeader";

const Overview = () => {
  const names = ["overview", "rules", "discussion", "files"];
  const components = [<>overbiew</>, <>rules</>, <>m</>, <>n</>];
  // const { challenge } = useChallenge();
  return (
    <>
      <ManagerPageHeader></ManagerPageHeader>

      <TabsMenu names={names} components={components} />
    </>
  );
};
export default Overview;
