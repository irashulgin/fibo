import { FC } from "react";
import ThanksPage from "../../commons/ThanksPage";

const CompanyCreated: FC = () => {
  return (
    <ThanksPage
      title={`Thank you\nfor creating new organization`}
      text={`please wait for our team to verify your\n company before publishing`}
      footer={`we will let you know when it is confirmed`}
    />
  );
};
export default CompanyCreated;
