import { Box, Typography } from "@mui/material";
import { FC } from "react"; 
import { API_URL } from "../../http";
import useCompany from "../../hooks/use-company";
import TabsMenu from "../../commons/TabsMenu";
import CompanyAbout from "./CompanyAbout";
import CompanyActivity from "./CompanyActivity";

import AddActionsMenu from "../AddActionsMenu";
 
const CompanyProfile: FC = () => {
  const { company  } = useCompany();

  return (
    <Box sx={{ display: "flex", flexDirection: "column" }}>
      {company && <img alt='' src={`${API_URL}/${company.logo}`} width="169px" />}
      <Typography>Fibonacci Challenges</Typography>
      <TabsMenu
        names={["About", "Activity"]}
        components={[<CompanyAbout />, <CompanyActivity />]}
      />
      <Box sx={{ display: "flex", alignSelf: "flex-end" }}>
        <AddActionsMenu />
      </Box>

      {/* reffered  
      {user.role === "Admin" ? <Button>Invite</Button> : <></>}
      {<PersonAddAltIcon onClick={() => navigate("/refer")} />} */}
    </Box>
  );
};
export default CompanyProfile;
