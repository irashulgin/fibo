import {  Button } from "@mui/material";
import { FC } from "react";
// import useCompany from "../../hooks/use-company";
import { GlobalStyledBox } from "../../commons/GlobalStyle";

const CompanyActivity: FC = () => {
  // const { company, error, isLoading } = useCompany();
  return (
    <GlobalStyledBox>
      <Button>Challenges</Button>
      <Button>Challenges in progress</Button>
      <Button>Events</Button>
    </GlobalStyledBox>
  );
};
export default CompanyActivity;
