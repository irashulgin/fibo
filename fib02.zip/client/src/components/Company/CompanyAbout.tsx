import { Box, Typography } from "@mui/material";
import { FC } from "react";
import useCompany from "../../hooks/use-company";

const CompanyAbout:FC=()=>{
    const {company}= useCompany();
    return (
        <Box>
            <Typography>About</Typography>
            {company.description}
            <Typography>Industry</Typography>
            {company.industry}
            <Typography>Company size</Typography>
            {company.tags}
            {/* todo check size */}
        </Box>
    )
}
export default CompanyAbout;