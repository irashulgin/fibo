import { Box, Chip, IconButton, TextField } from "@mui/material";
import { FC, useEffect, useState } from "react";
import { useAppDispatch } from "../../hooks/redux";
import useUser from "../../hooks/use-user";
import { createCompany } from "../../actions/companyActions";
import useTagInput from "../../hooks/useTagInput";
import NextButton from "../../commons/Nextbutton";
import useAuth from "../../hooks/use-auth";
import { useNavigate } from "react-router-dom";
import useCompany from "../../hooks/use-company";

const NewCompany: FC = () => {
  const { user } = useUser();
  const {
    tagInput,
    handleTagInputChange,
    handleAddTag,
    handleRemoveTag,
    tags,
  } = useTagInput();
  const [name, setName] = useState<string>("");
  const [city, setCity] = useState<string>("");
  const [industry, setIndustry] = useState<string>("");
  const [type, setType] = useState<string>("");
  const [description, setDescription] = useState<string>("");

  const { company, isLoading } = useCompany();

  const dispatch = useAppDispatch();
  const auth = useAuth();
  const navigate = useNavigate();
  useEffect(() => {
    if (Object.keys(company).length > 0 && !isLoading) {
      navigate("/company-created");
    }
  }, [company]);
  const createNewCompany = async () => {
    const company = {
      email: user.email,
      tags,
      city,
      industry,
      type,
      description,
      name,
    };
    await dispatch(createCompany(company));
  };
  const uploadFile = (e: any) => {
    // const file = e.target.files[0];
    // dispatch(saveCompanyFile(user.email,file));
  };
  return (
    <Box>
      <TextField
        id="companyName"
        name="companyName"
        label="Company name"
        variant="outlined"
        fullWidth
        margin="normal"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <TextField
        id="city"
        name="city"
        label="City"
        variant="outlined"
        fullWidth
        margin="normal"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <TextField
        id="industry"
        name="industry"
        label="Industry"
        variant="outlined"
        fullWidth
        margin="normal"
        value={industry}
        onChange={(e) => setIndustry(e.target.value)}
      />
      <TextField
        id="type"
        name="type"
        label="Organization type"
        variant="outlined"
        fullWidth
        margin="normal"
        value={type}
        onChange={(e) => setType(e.target.value)}
      />

      <Box>
        <input
          accept="image/*"
          // className={classes.input}
          id="icon-button-photo"
          onChange={uploadFile}
          type="file"
        />
      </Box>
      <label htmlFor="icon-button-photo">
        <IconButton color="primary" component="span">
          Upload logo
        </IconButton>
      </label>

      <TextField
        label="Tags"
        variant="outlined"
        value={tagInput}
        onChange={handleTagInputChange}
        onKeyDown={(e) => e.key === "Enter" && handleAddTag()}
        InputProps={{
          startAdornment: (
            <>
              {tags.map((tag) => (
                <Chip
                  key={tag}
                  label={tag}
                  onDelete={() => handleRemoveTag(tag)}
                  color="primary"
                  variant="outlined"
                  sx={{ margin: "2px" }}
                />
              ))}
            </>
          ),
        }}
      />

      <TextField
        id="description"
        name="description"
        label="Description"
        variant="outlined"
        fullWidth
        multiline={true}
        margin="normal"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />
      <Box sx={{ marginLeft: "auto" }}>
        <NextButton onClick={createNewCompany}></NextButton>
      </Box>
      {/* {infoMsg && <InfoMessage message={infoMsg}  />} */}

      {auth.error}
    </Box>
  );
};
export default NewCompany;
