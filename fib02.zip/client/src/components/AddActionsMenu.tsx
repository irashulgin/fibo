import { FC } from "react";

import React, { useState } from "react";
import { IconButton, Menu, MenuItem } from "@mui/material";

import AddCircleIcon from "@mui/icons-material/AddCircle";

const AddActionsMenu: FC = () => {
  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  //todo to set onclick events to menu

  return (
    <div>
      <IconButton onClick={handleClick} color="inherit">
        <AddCircleIcon fontSize="large" color="action" />
      </IconButton>
      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleClose}>
        <MenuItem onClick={handleClose}>Create Challenge</MenuItem>
        <MenuItem onClick={handleClose}>Create event </MenuItem>
        <MenuItem onClick={handleClose}>Add new employee </MenuItem>
      </Menu>
    </div>
  );
};

export default AddActionsMenu;
