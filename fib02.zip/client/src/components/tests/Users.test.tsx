import { render } from "@testing-library/react";
import Users from "../User/Users";
import React from 'react'
import { useSelector } from "react-redux";
// import { useAppDispatch, useAppSelector } from "

// describe("users", () => {
//   it("should create users list with empty array", () => {
//     //@ts-ignore
//     const component:any = render(<Users/>);
//     // expect(component).toMatchSnapshot()
//   });
// });
// jest.mock('react-redux')
import * as reactRedux from 'react-redux'

// describe('test suite', () => {
  const useSelectorMock = jest.spyOn(reactRedux, 'useSelector')
  const useDispatchMock = jest.spyOn(reactRedux, 'useDispatch')
 
// })
beforeEach(() => {
  useSelectorMock.mockClear()
  useDispatchMock.mockClear()
})
test('users', () => {
  const useSelectorMock = jest.spyOn(reactRedux, 'useSelector')
  // const useDispatchMock = jest.spyOn(reactRedux, 'useDispatch')
    useSelectorMock.mockReturnValue([])
    // const users = render(<Users />);
    
    // expect(users).toBeInTheDocument();
  });
  