import { Typography } from "@mui/material";
import { FC } from "react";
import { SVGFib } from "../images/fib";
import NextButton from "../commons/Nextbutton";

const ReferenceScreen: FC = () => {
  const nextOnClick = async () => {};
  return (
    <>
      <Typography>Welcome to Fibonacci</Typography>
      <SVGFib />

      <NextButton onClick={nextOnClick} />
    </>
  );
};
export default ReferenceScreen;
