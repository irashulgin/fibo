import { useAppSelector } from "./redux";
const useError = () => {
  const error = useAppSelector((state) => state.error);
  return error;
};
export default useError;
