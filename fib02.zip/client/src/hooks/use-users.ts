import { useAppSelector } from "./redux";
const useUsers = ()=>{
    const users  = useAppSelector(state=>state.userList);
    return users;
}
export default useUsers;