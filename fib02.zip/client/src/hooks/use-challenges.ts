import { useAppSelector } from "./redux";
const useChallenges = () => {
  const challenges = useAppSelector((state) => state.challengesList);
  return challenges;
};
export default useChallenges;
