import { useState } from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';

const useFormWithValidation = (initialValues:any, validationSchema:any, onSubmit:(values:any)=>void) => {
  const [serverError, setServerError] = useState(null);

  const formik = useFormik({
    initialValues,
    validationSchema: Yup.object(validationSchema),
    onSubmit: async (values, { setSubmitting }) => {
      try {
        // Call your API or perform the submit logic here
        
        await onSubmit(values);
      } catch (error:any) {
        setServerError(error.message);
      } finally {
        setSubmitting(false);
      }
    },
  });

  const resetServerError = () => {
    setServerError(null);
  };

  return {
    ...formik,
    serverError,
    resetServerError,
  };
};

export default useFormWithValidation;
