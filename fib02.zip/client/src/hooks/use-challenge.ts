import { useAppSelector } from "./redux";
const useChallenge = () => {
  const challenge = useAppSelector((state) => state.challenge);
  return challenge;
};
export default useChallenge;
