import { useAppSelector } from "./redux";
const useEvents = () => {
  const events = useAppSelector((state) => state.event.event);
  return events;
};
export default useEvents;
