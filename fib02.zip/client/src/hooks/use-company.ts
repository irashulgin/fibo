import { useAppSelector } from "./redux";
const useCompany = () => {
  const company = useAppSelector((state) => state.company);
  return company;
};
export default useCompany;
