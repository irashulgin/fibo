import axios from "axios";
import { createAsyncThunk } from "@reduxjs/toolkit";
import AuthService from "../service/authService";
import { IUser } from "../models/IUser";
import { AuthResponse } from "../models/response/AuthResponse";
import { API_URL } from "../http";
import { setAuth, setError } from "../store/reducers/AuthSlice";
import { updateUserData } from "./userActions";
import { updateErrorMessage } from "./errorActions";
import { updateSuccess } from "../store/reducers/ErrorSlice";

const backendURL = "http://127.0.0.1:5000";

export const registerUser2 = createAsyncThunk(
  "auth/register",
  async (userData, { rejectWithValue }) => {
    try {
      const config = {
        headers: {
          "Content-Type": "application/json",
        },
      };
      await axios.post(`${backendURL}/api/user/register`, { userData }, config);
    } catch (error: any) {
      // return custom error message from backend if present
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message);
      } else {
        return rejectWithValue(error.message);
      }
    }
  }
);

export const registerUser = (userData: IUser) => {
  return async (dispatch: any) => {
    try {
      const response = await AuthService.registration(userData);
      localStorage.setItem("token", response?.data?.accessToken);
      dispatch(setAuth(true));
      dispatch(updateUserData(response?.data?.user));
      dispatch(updateErrorMessage(""));
    } catch (error: any) {
      dispatch(setError(error?.response?.data?.message));
      dispatch(updateErrorMessage(error?.response?.data?.message));
      return null;
    }
  };
};

export const forgotUserPassword = (email: string) => {
  return async (dispatch: any) => {
    try {
      const response = await AuthService.forgotPassword(email);
      dispatch(updateSuccess("Email has been sent"));
    } catch (error: any) {
      dispatch(setError(error?.response?.data?.message));
      dispatch(updateErrorMessage(error?.response?.data?.message));
    }
  };
};
export const loginUser = (email: string, password: string) => {
  return async (dispatch: any) => {
    try {
      const response = await AuthService.login(email, password);
      localStorage.setItem("token", response?.data?.accessToken);
      dispatch(setAuth(true));
      dispatch(updateUserData(response.data.user));
      dispatch(updateErrorMessage(""));
    } catch (error: any) {
      dispatch(setError(error?.response?.data?.message));
      dispatch(updateErrorMessage(error?.response?.data?.message));
    }
  };
};

export const logout = () => {
  return async (dispatch: any) => {
    try {
      await AuthService.logout();
      localStorage.removeItem("token");
      debugger;
      dispatch(setAuth(false));
      dispatch(updateUserData({} as IUser));
      dispatch(updateErrorMessage(""));
      dispatch(updateSuccess(""));
    } catch (error: any) {
      dispatch(updateErrorMessage(error?.response?.data?.message));
      dispatch(setError(error?.response?.data?.message));
    }
  };
};

export const resetPassword = (token: string, password: string) => {
  return async (dispatch: any) => {
    try {
      await AuthService.resetPassword(token, password);
      dispatch(updateErrorMessage(""));
      dispatch(updateSuccess("Password has been changed"));
    } catch (error: any) {
      dispatch(updateErrorMessage(error?.response?.data?.message));
      dispatch(updateSuccess(""));
    }
  };
};

export const checkAuth = () => {
  return async (dispatch: any) => {debugger;
    try {
      const response = await axios.get<AuthResponse>(`${API_URL}/refresh`, {
        withCredentials: true,
      });
      localStorage.setItem("token", (await response).data.accessToken);
      //if (response.status === 200) {
        dispatch(setAuth(true));
        dispatch(updateUserData(response?.data?.user));
      //}
    } catch (e: any) {
      dispatch(setError(e?.response?.data?.message));
      dispatch(setAuth(false));
    }
  };
};
