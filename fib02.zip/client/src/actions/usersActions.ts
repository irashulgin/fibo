import { createAsyncThunk } from "@reduxjs/toolkit";
import UserListService from "../service/userListService";
 

export const fetchUsers = createAsyncThunk(
  "userList",
  async (searchTerm: string, thunkAPI) => {
    try {
      const response = await UserListService.fetchUsers(searchTerm);
      return response.data;
    } catch (e: any) {
      return thunkAPI.rejectWithValue("Can't get users list");
    }
  }
);
