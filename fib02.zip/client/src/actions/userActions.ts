import { setImageUrl, updateUser } from "../store/reducers/UserSlice";
import UserService from "../service/userService";
import { updateErrorMessage } from "./errorActions";
import { updateSuccess } from "../store/reducers/ErrorSlice";

export const collectData = (userData: any) => {
  return async (dispatch: any) => {
    try {
      const response = await UserService.collect(userData);
      dispatch(updateUserData(response.data));
      dispatch(updateErrorMessage(""));
      dispatch(updateUser(response?.data?.user));
    } catch (error: any) {
      dispatch(updateErrorMessage(error?.response?.data?.message));
    }
  };
};

export const updateUserData = (userData: any) => {
  return async (dispatch: any) => {
    try {
      dispatch(updateUser(userData));
      dispatch(updateErrorMessage(""));
    } catch (error: any) {
      dispatch(updateErrorMessage(error?.response?.data?.message));
    }
  };
};
export const saveFile = (email: string, file: any) => {
  return async (dispatch: any) => {
    try {
      const response = await UserService.upload(email, file);

      dispatch(setImageUrl(response?.data?.url));
      dispatch(updateErrorMessage(""));

      return {
        type: "UPLOAD_FILE",
        payload: file,
      };
    } catch (error: any) {
      dispatch(updateErrorMessage(error?.response?.data?.message));
    }
  };
};

export const inviteUser = (userData: any, curUser?: string, note?: string) => {
  return async (dispatch: any) => {
    try {
      await UserService.inviteUser(userData, curUser, note);

      dispatch(updateErrorMessage(""));
      dispatch(updateSuccess("User invited"));
    } catch (error: any) {
      dispatch(updateErrorMessage(error?.response?.data?.message));
      dispatch(updateSuccess(""));
    }
  };
};
