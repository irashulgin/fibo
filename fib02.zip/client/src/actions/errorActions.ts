
import { ErrorState, updateError } from "../store/reducers/ErrorSlice";

export const updateErrorMessage = (errorMsg: string) => {
  return async (dispatch: any) => {
    try {
      dispatch(updateError(errorMsg));
    } catch (error: any) {
      dispatch(updateError(error));
    }
  };
};
export const getErrorMessage = (state: ErrorState) => state.errorMessage;

export const getSuccessMessage = (state: ErrorState) => state.successMessage;

