import { createAsyncThunk } from "@reduxjs/toolkit";
import ChallengeService from "../service/challengeService";

export const fetchChallenges = createAsyncThunk(
  "challengesList",
  async (search: { searchTerm: string; email: string }, thunkAPI) => {
    try {
      const response = await ChallengeService.fetchChallenges(
        search.searchTerm,
        search.email
      );

      return response.data;
    } catch (e: any) {
      return thunkAPI.rejectWithValue("Cant get challenges list");
    }
  }
);
