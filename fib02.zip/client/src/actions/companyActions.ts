import CompanyService from "../service/companyService";
import { updateCompany } from "../store/reducers/CompanySlice";
import { updateSuccess } from "../store/reducers/ErrorSlice";
import { updateErrorMessage } from "./errorActions";

export const createCompany = (company: any) => {
  return async (dispatch: any) => {
    try {
      const response = await CompanyService.createCompany(company);
      dispatch(updateCompany(response.data));
      dispatch(updateErrorMessage(""));
      dispatch(updateSuccess("Company created"));
    } catch (error: any) {
      console.log(error);
      dispatch(updateErrorMessage(error?.response?.data?.message));
    }
  };
};

// export const saveCompanyFile = (email:string,file: any) => {
//   return async (dispatch: any) => {
//     try {
//       const response = await ChallengeService.uploadCompany(email,file);
//       // dispatch(updateUser(response?.data?.user));
//       dispatch(setCompanyImageUrl(response?.data?.url));
//       return {
//         type: "UPLOAD_FILE",
//         payload: file,
//       };
//     } catch (error: any) {
//       dispatch(setError(error?.response?.data?.message));
//     }
//   };
// };
