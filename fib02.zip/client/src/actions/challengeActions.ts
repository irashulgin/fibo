import ChallengeService from "../service/challengeService";
import { addNewChallenge } from "../store/reducers/ChallengesListSlice";
import {
  updateChallenge,
  setCompanyImageUrl,
} from "../store/reducers/ChallengeSlice";
import { updateErrorMessage } from "./errorActions";

export const addChallenge = (challenge: any) => {
  return async (dispatch: any) => {
    try {
      dispatch(updateChallenge(challenge));
      dispatch(updateErrorMessage(""));
    } catch (error: any) {
      dispatch(updateErrorMessage(error?.message));
    }
  };
};

export const saveChallenge = (challenge: any) => {
  return async (dispatch: any) => {
    try {
      await ChallengeService.addNewChallenge(challenge);
      dispatch(addNewChallenge(challenge));
      dispatch(updateErrorMessage(""));
    } catch (error: any) {
      dispatch(updateErrorMessage(error?.response?.data?.message));
    }
  };
};

export const saveCompanyFile = (email: string, file: any) => {
  return async (dispatch: any) => {
    try {
      const response = await ChallengeService.uploadCompany(email, file);
      dispatch(updateErrorMessage(""));
      dispatch(setCompanyImageUrl(response?.data?.url));
      return {
        type: "UPLOAD_FILE",
        payload: file,
      };
    } catch (error: any) {
      dispatch(updateErrorMessage(error?.response?.data?.message));
    }
  };
};
