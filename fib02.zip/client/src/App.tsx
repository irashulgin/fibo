import "./App.css";
import Register from "./components/Account/Register";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
  useNavigate,
} from "react-router-dom";

import UsersContainer from "./components/User/UsersContainer";
import Layout from "./components/Layout";
import Welcome from "./components/Account/Welcome";
import MemberId from "./components/MemberId";

import { ThemeProvider } from "@mui/material/styles";
import theme from "./styles/style";
import AccountInfo from "./components/Account/AccountInfo";
import SignUpDone from "./components/Account/SignUpDone";
import Login from "./components/Account/Login";
import UserScreen from "./components/User/UserScreen";
import UpdatePassword from "./components/Account/UpdatePassword";
import ReferenceScreen from "./components/ReferenceScreen";
import Manager from "./components/Manager";
import NewChallenge from "./components/Challenge/NewChallenge";
import Challenges from "./components/Challenge/Challenges";
import Scoring from "./components/Challenge/Scoring";
import DataCollecting from "./components/Account/DataCollecting";
import Schedule from "./components/Challenge/Shcedule";
import SignUp from "./components/Account/SignUp";
import UserProfile from "./components/User/UserProfile";
import TabsMenu from "./commons/TabsMenu";
import ReferFriend from "./components/ReferFriend";
import NewCompany from "./components/Company/NewCompany";
import CompanyCreated from "./components/Company/CompanyCreated";
import Feed from "./components/User/Feed";
import CompanyProfile from "./components/Company/CompanyProfile";
import Creteria from "./components/Challenge/Creteria";
import Rules from "./components/Challenge/Rules";
import ChallengeCreated from "./components/Challenge/ChallengeCreated";
import Overview from "./components/Manager/Overview";
import ForgotPassword from "./components/Account/ForgotPassword";
import ProtectedRoute from "./commons/ProtectedRoute";

function App() {
  return (
    <Router>
      <ThemeProvider theme={theme}>
        <Layout>
          <Routes>
            <Route path="/signup" element={<SignUp />} />
            <Route path="/register" element={<Register />} />
            <Route path="/users" element={<UsersContainer />} />
            <Route path="/welcome" element={<Welcome />} />
            <Route path="/account-info" element={<AccountInfo />} />
            <Route path="/signup-done" element={<SignUpDone />} />
            <Route path="/member-id" element={<MemberId />} />
            <Route path="/login" element={<Login />} />
            <Route path="/user-screen" element={<UserScreen />} />
            <Route path="/reset-password" element={<UpdatePassword />} />
            <Route path="/reset-password/:token" element={<UpdatePassword />} />
            <Route path="/reference" element={<ReferenceScreen />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route
              path="/manager"
              element={<Manager/>}/>
            {/* <Route
              path="/manager"
              element={<ProtectedRoute component={Manager} />}
            /> */}
            <Route
              path="/new-challenge"
              element={<NewChallenge/>}/>
            {/* <Route
              path="/new-challenge"
              element={<ProtectedRoute component={NewChallenge} />}
            /> */}

            <Route
              path="/challenges"
              element={<Challenges/>} />
            
            <Route
              path="/scoring"
              element={<Scoring/>}
            />
            {/* <Route
              path="/user-profile"
              element={
                <ProtectedRoute
                  component={() => (
                    <TabsMenu
                      names={["Profile", "Feed"]}
                      components={[<UserProfile />, <Feed />]}
                    />
                  )}
                />
              }
            /> */}
            <Route
              path="/user-profile"
              element={<TabsMenu
                      names={["Profile", "Feed"]}
                      components={[<UserProfile />, <Feed />]}
                    />
                  }
                />
              
            

            <Route path="/data-collecting" element={<DataCollecting />} />
            <Route path="/schedule" element={<Schedule />} />
            <Route path="/refer" element={<ReferFriend />} />
            <Route path="/new-company" element={<NewCompany />} />
            <Route path="/company-created" element={<CompanyCreated />} />
            <Route path="/company-profile" element={<CompanyProfile />} />
            <Route path="/creteria" element={<Creteria />} />
            <Route path="/rules" element={<Rules />} />
            <Route path="/challenge-created" element={<ChallengeCreated />} />
            <Route path="/overview" element={<Overview />} />
          </Routes>

          {/*  
        <Route component={NotFound} /> */}
        </Layout>
      </ThemeProvider>
    </Router>
  );
}

export default App;
