import { createSlice } from "@reduxjs/toolkit";
import { IUser } from "../../models/IUser";

interface UserState {
  user: IUser;
  isLoading: boolean;
  error: string;
}

const initialState: UserState = {
  user: {} as IUser,
  isLoading: false,
  error: "",
};

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    updateUser: (state, action) => {
      // state.userInfo = action.payload;
      state.user = { ...state.user, ...action.payload };
    },
    setImageUrl: (state, action) => {
      state.user.imageUrl = action.payload;
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
  },
});

export const { setError, updateUser, setImageUrl } = userSlice.actions;

export default userSlice.reducer;
