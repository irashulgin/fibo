import { createSlice } from "@reduxjs/toolkit";
import { ICompany } from "../../models/ICompany";

interface CompanyState {
  company: ICompany;
  isLoading: boolean;
  error: string;
}

const initialState: CompanyState = {
  company: {} as ICompany,
  isLoading: false,
  error: "",
};

export const CompanySlice = createSlice({
  name: "company",
  initialState,
  reducers: {
    setCompanyImageUrl: (state, action) => {
      state.company.logo = action.payload;
    },
    updateCompany: (state, action) => {
      state.company = {
        ...state.company,
        ...action.payload, // update only the properties provided in payload
      };
    },
  },
});

export const { updateCompany, setCompanyImageUrl } = CompanySlice.actions;

export default CompanySlice.reducer;
