import { PayloadAction, createSlice } from "@reduxjs/toolkit";
import { IUser } from "../../models/IUser";
import { fetchUsers } from "../../actions/usersActions";

interface UsersState {
  userList: IUser[];
  isLoading: boolean;
  error: string;
}

const initialState: UsersState = {
  userList: [],
  isLoading: false,
  error: "",
};

export const userListSlice = createSlice({
  name: "userList",
  initialState,
  reducers: {},

  extraReducers: (builder: any) => {
    builder
      .addCase(fetchUsers.pending, (state: any) => {
        state.isLoading = true;
        state.error = "";
      })
      .addCase(
        fetchUsers.fulfilled,
        (state: any, action: PayloadAction<IUser[]>) => {
          state.isLoading = false;
          state.error = "";
          state.userList = action.payload;
        }
      )
      .addCase(
        fetchUsers.rejected,
        (state: any, action: PayloadAction<IUser[]>) => {
          state.isLoading = false;
          state.error = action.payload;
        }
      );
  },
});

export default userListSlice.reducer;
