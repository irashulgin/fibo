import { createSlice } from "@reduxjs/toolkit";
import { IChallenge } from "../../models/IChallenge";

interface ChallengeState {
  challenge: IChallenge;
  isLoading: boolean;
  error: string;
}

const initialState: ChallengeState = {
  challenge: {} as IChallenge,
  isLoading: false,
  error: "",
};

export const ChallengeSlice = createSlice({
  name: "challenge",
  initialState,
  reducers: {
    setCompanyImageUrl: (state, action) => {
      state.challenge.imageUrl = action.payload;
    },
    updateChallenge: (state, action) => {
      // state.challenge = action.payload;
      state.challenge = {
        ...state.challenge,
        ...action.payload, // update only the properties provided in payload
      };
    },
  },
});

export const { updateChallenge, setCompanyImageUrl } = ChallengeSlice.actions;

export default ChallengeSlice.reducer;
