import { createSlice } from "@reduxjs/toolkit";

interface IUser {
  id: string;
  isActive: boolean;
  firstName: string;
  lastName: string;
  reference: number;
  state: string;
  phone: number;
  profession: string;
  city: string;
  email: string;
  password: string;
  role: string;
  uploadedFile?: File | null;
  previewUrl?: string;
  birthDate: Date;
  currentWork: string;
  institute: string;
}
interface InitUser {
  userInfo: IUser;
  isAuth: boolean;
  loading: boolean;
  userToken: string | null;
  error: string | null;
  success: boolean;
}

const initialState: InitUser = {
  isAuth: false,
  loading: false,
  userInfo: {} as IUser,
  userToken: null,
  error: "",
  success: false,
};

export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    setUser: (state, action) => {
      state.userInfo = action.payload;
    },
    setAuth: (state, action) => {
      state.isAuth = action.payload;
      state.error = "";
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
  },
});

export const { setUser, setAuth, setError } = authSlice.actions;

export default authSlice.reducer;
