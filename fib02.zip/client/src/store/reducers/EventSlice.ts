import { createSlice } from "@reduxjs/toolkit";
import { IEvent } from "../../models/IEvent";

interface EventState {
  event: IEvent;
  isLoading: boolean;
  error: string;
}

const initialState: EventState = {
  event: {} as IEvent,
  isLoading: false,
  error: "",
};

export const EventSlice = createSlice({
  name: "company",
  initialState,
  reducers: {
    addEvent: (state, action) => {
      state.event = action.payload;
    },
  },
});

export const { addEvent } = EventSlice.actions;

export default EventSlice.reducer;
