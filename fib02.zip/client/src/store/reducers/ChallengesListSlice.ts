import { PayloadAction, createSlice } from "@reduxjs/toolkit";
import { IChallenge } from "../../models/IChallenge";
import { fetchChallenges } from "../../actions/challengesListActions";

interface ChallengeListState {
  challengesList: IChallenge[];
  isLoading: boolean;
  error: string;
}

const initialState: ChallengeListState = {
  challengesList: [],
  isLoading: false,
  error: "",
};

export const ChallengesListSlice = createSlice({
  name: "challengesList",
  initialState,
  reducers: {
    addNewChallenge: (state, action) => {
      state.challengesList = [...state.challengesList, action.payload];
    },
    // updateChallenge : (state, action) => {
    //   state.challenges = [...state.challenges,action.payload];
    // }
  },

  extraReducers: (builder: any) => {
    builder
      .addCase(fetchChallenges.pending, (state: any) => {
        state.isLoading = true;
        state.error = "";
      })
      .addCase(
        fetchChallenges.fulfilled,
        (state: any, action: PayloadAction<IChallenge[]>) => {
          state.isLoading = false;
          state.error = "";
          state.challengesList = action.payload;
        }
      )
      .addCase(
        fetchChallenges.rejected,
        (state: any, action: PayloadAction<IChallenge[]>) => {
          state.isLoading = false;
          state.error = action.payload;
        }
      );
  },
});

export const { addNewChallenge } = ChallengesListSlice.actions;

export default ChallengesListSlice.reducer;
