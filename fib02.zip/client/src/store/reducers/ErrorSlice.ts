import { createSlice } from "@reduxjs/toolkit";

export interface ErrorState {
  errorMessage: string;
  successMessage: string;
}

const initialState: ErrorState = {
  errorMessage: "",
  successMessage: "",
};

export const ErrorSlice = createSlice({
  name: "error",
  initialState,
  reducers: {
    updateError: (state, action) => {
      state.errorMessage = action.payload;
    },
    updateSuccess: (state, action) => {
      state.successMessage = action.payload;
    },
  },
});

export const { updateError, updateSuccess } = ErrorSlice.actions;

export default ErrorSlice.reducer;
