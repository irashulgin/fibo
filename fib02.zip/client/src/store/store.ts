import { combineReducers, configureStore } from "@reduxjs/toolkit";
import authReducer from "./reducers/AuthSlice";
import usersReducer from "./reducers/UserListSlice";
import challengesReducer from "./reducers/ChallengesListSlice";
import challengeReducer from "./reducers/ChallengeSlice";
import companyReducer from "./reducers/CompanySlice";
import userReducer from "./reducers/UserSlice";
import eventReducer from "./reducers/EventSlice";
import errorReducer from "./reducers/ErrorSlice";

const rootReducer = combineReducers({
  auth: authReducer,
  userList: usersReducer,
  challengesList: challengesReducer,
  challenge: challengeReducer,
  user: userReducer,
  company: companyReducer,
  event:eventReducer,
  error:errorReducer
});

export const setupStore = () => {
  return configureStore({
    reducer: rootReducer,
  });
};

export type RootState = ReturnType<typeof rootReducer>;
export type AppStore = ReturnType<typeof setupStore>;
export type AppDispatch = AppStore["dispatch"];
