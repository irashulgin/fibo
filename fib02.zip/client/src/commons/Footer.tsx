import { makeStyles } from "@material-ui/core/styles";
import { BottomNavigation, BottomNavigationAction } from "@mui/material";
import PersonAddAltIcon from "@mui/icons-material/PersonAddAlt";
import { useNavigate } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  footer: {
    position: "fixed",
    bottom: 0,
    left: 0,
    width: "100%",
    // backgroundColor: theme.palette.primary.main,
    color: theme.palette.primary.contrastText,
    textAlign: "center",
  },
  icon: {
    position: "absolute",
    bottom: "5px",
    right: "5px",
  },
}));

function Footer() {
  const classes = useStyles();
  const navigate = useNavigate();

  return (
    <BottomNavigation className={classes.footer}>
      <BottomNavigationAction
        label="Home"
        icon={<PersonAddAltIcon onClick={() => navigate("/refer")} />}
        className={classes.icon}
      />
    </BottomNavigation>
  );
}

export default Footer;
