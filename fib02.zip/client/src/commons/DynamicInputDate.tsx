import { Input } from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers-pro";
import React, { useEffect, useState } from "react";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";

function DynamicInputDate({ onFieldsChange }:any) {
  const [fields, setFields] = useState([{ inputValue: "", dateValue: "" }]);
  useEffect(() => {
    onFieldsChange(fields);
  }, [fields, onFieldsChange]);

  // Function to handle addition of input fields and date components
  const handleAddField = () => {
    setFields([...fields, { inputValue: "", dateValue: "" }]);
    //dispatch
  };

  // Function to handle changes in input field
  const handleInputChange = (index: number, event: any) => {
    const values = [...fields];
    values[index].inputValue = event.target.value;
    setFields(values);
  };

  // Function to handle changes in date component
  const handleDateChange = (val: any, index: number) => {
    const values = [...fields];
    values[index].dateValue = val.toLocaleString()
    setFields(values);
  };

  return (
    <div>
      {fields.map((field, index) => (
        <div key={index}>
          <Input
            type="text"
            value={field.inputValue}
            onChange={(e) => handleInputChange(index, e)}
          />
          {/* <Input
            type="date"
            value={field.dateValue}
            onChange={(e) => handleDateChange(index, e)}
          /> */}

          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DatePicker
              label="Last date to Register"
              value={field.dateValue}
              onChange={
                //(e) => handleDateChange(index, e)
                (newValue: string | null) => handleDateChange(newValue, index)
                // setLastRegisterDate(newValue)
              }
            />
          </LocalizationProvider>
        </div>
      ))}
      <button onClick={handleAddField}>+</button>
    </div>
  );
}

export default DynamicInputDate;
