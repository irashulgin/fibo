import React, { useState } from "react";
import Snackbar from "@mui/material/Snackbar";
// import MuiAlert from "@mui/material/Alert";
import { Paper, Typography } from "@mui/material";

// function Alert(props: any) {
//   return <MuiAlert elevation={6} variant="filled" {...props} />;
// }

const InfoMessage = (props: { message: string; isError: boolean }) => {
  const { message, isError } = props;
  const [open, setOpen] = useState(true);

  const color = isError ? "#f44336" : "#2e7d32";
  const handleClose = (event: any, reason: string) => {
    // if (reason === "clickaway") {
    //   return;
    // }
    setOpen(false);
  };

  const paperStyle = {
    backgroundColor: color,
    padding: "15px",r: "#fff",
    borderRadius: "5px",
  };

  return (
    <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
      <Paper elevation={3} style={paperStyle}>
        <Typography variant="body1"> {message}</Typography>
      </Paper>
    </Snackbar>
  );
};

export default InfoMessage;
