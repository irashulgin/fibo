import { ComponentType, useEffect } from "react";
import { Navigate } from "react-router-dom";
import useAuth from "../hooks/use-auth";
import { useAppDispatch } from "../hooks/redux";
import { checkAuth } from "../actions/authActions";
 
interface ChildComponentProps {
  component: ComponentType<any>;
}

const ProtectedRoute = ({
  component: Component,
  ...rest
}: ChildComponentProps) => {
  const dispatch = useAppDispatch();
  const auth = useAuth();

  // useEffect(() => {
  // c = auth.isAuth ? <Component {...rest} /> : <Navigate to="/login" />;
  // }, [auth.isAuth]);
  useEffect(() => {
    if (localStorage.getItem("token")) {
      dispatch(checkAuth());
    }
  }, []);
  // if (localStorage.getItem("token")) {
  // dispatch(checkAuth());
  return auth.isAuth ? <Component {...rest} /> : <Navigate to="/login" />;
};
export default ProtectedRoute;
