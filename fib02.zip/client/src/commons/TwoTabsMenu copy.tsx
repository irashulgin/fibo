// Import necessary components from Material-UI
import React, { ReactNode } from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import UserProfile from "../components/User/UserProfile";
import Feed from "../components/User/Feed";

// Your component function
function TwoTabsMenu(props: {
  name1: string;
  name2: string;
  component1: ReactNode;
  component2:ReactNode;
}) {
  const { name1, name2,component1,component2 } = props;
  // State to manage the active tab
  const [value, setValue] = React.useState(0);

  // Event handler for tab change
  const handleChange = (event: any, newValue: number) => {
    setValue(newValue);
  };

  return (
    <Box>
      {/* Tabs component with two Tab components */}
      <Tabs value={value} onChange={handleChange} centered variant="fullWidth">
        <Tab label={name1} />
        <Tab label={name2} />
      </Tabs>
      {/* Content for each tab */}
      <Box>
        {/* sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}> */}
        {value === 0 && (
          <div>
            {/* <UserProfile /> */}
            {component1}
          </div>
        )}
        {value === 1 && (
          <div>
            {/* <Feed /> */}
            {component2}
          </div>
        )}
      </Box>
    </Box>
  );
}

export default TwoTabsMenu;
