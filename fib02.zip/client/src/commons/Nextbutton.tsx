import styled from '@emotion/styled'

const Button = styled.button`
  color: #fff;
  width: 6.25rem;
  height: 2.5rem;
  background:#1976d2;
  border-radius: 10px;
  border:1px solid #1976d2;
  font-weight: 500;
    font-size: 0.875rem;
    line-height: 1.75;
    text-transform: uppercase;
    min-width: 64px;
    padding: 6px 16px;
    border-radius: 4px;
    font-family: Montserrat,sans-serif;
`

type MyFunctionType = {onClick : () => void, type?: "button" | "submit" | "reset" | undefined};

const NextButton = (props:MyFunctionType) => {
    const {onClick, type} = props; 

    return (
        <Button onClick={onClick} type={type}>{`Next >>`}</Button>
    )
}
export default NextButton;