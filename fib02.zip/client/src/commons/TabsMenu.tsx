
import React, { ReactNode } from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
 

 
function TabsMenu(props: { names: string[]; components: ReactNode[] }) {
  const { names, components } = props;
  // State to manage the active tab
  const [value, setValue] = React.useState(0);

  // Event handler for tab change
  const handleChange = (event: any, newValue: number) => {
    setValue(newValue);
  };

  return (
    <Box>
      {/* Tabs component with two Tab components */}
      <Tabs value={value} onChange={handleChange} centered variant="fullWidth">
        {names.map((name) => (
          <Tab label={name} key={name}/>
        ))}
      </Tabs>
      {/* Content for each tab */}
      <Box>
        {/* sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}> */}

        {components.map((comp, index) => {
          if (value === index) {
            return comp;
          }
        })}

        {/* {value === 0 && (
          <div>
            {/ <UserProfile /> /}
            {component1}
          </div>
        )}
        {value === 1 && (
          <div>
            {/* <Feed /> /}
            {component2}
          </div>
        )} */}
      </Box>
    </Box>
  );
}

export default TabsMenu;
