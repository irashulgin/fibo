import React, { FC, useEffect, useState } from "react";
import Drawer from "@mui/material/Drawer";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import { IconButton } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import { Link, useNavigate } from "react-router-dom";
import { useAppDispatch } from "../hooks/redux";
import { logout } from "../actions/authActions";
import useError from "../hooks/use-error";

const LeftMenu: FC = () => {
  const [isDrawerOpen, setDrawerOpen] = useState(false);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const toggleDrawer = (open: boolean) => () => {
    setDrawerOpen(open);
  };

  const error = useError();

  // useEffect(() => {
  //   if (error.successMessage) {
  //     navigate("/login");
  //   }
  // }, [error.successMessage]);

  const logoutUser = async () => {
    try {
      dispatch(logout());
      toggleDrawer(false);
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <div>
      <IconButton onClick={toggleDrawer(true)}>
        <MenuIcon />
      </IconButton>
      <Drawer anchor="left" open={isDrawerOpen} onClose={toggleDrawer(false)}>
        <List>
          <ListItem
            component={Link}
            to="/challenges"
            onClick={toggleDrawer(false)}
          >
            <ListItemText primary="Your challenges" />
          </ListItem>
          <ListItem
            component={Link}
            to="/new-challenge"
            onClick={toggleDrawer(false)}
          >
            <ListItemText primary="Create challenge" />
          </ListItem>

          <ListItem
            component={Link}
            to="/events-info"
            onClick={toggleDrawer(false)}
          >
            <ListItemText primary="Your events" />
          </ListItem>
          <ListItem
            component={Link}
            to="/rewards-info"
            onClick={toggleDrawer(false)}
          >
            <ListItemText primary="Your rewards" />
          </ListItem>
          <ListItem
            component={Link}
            to="/company-profile"
            onClick={toggleDrawer(false)}
          >
            <ListItemText primary="Manage company" />
          </ListItem>
          <ListItem
            component={Link}
            to="/new-company"
            onClick={toggleDrawer(false)}
          >
            <ListItemText primary="Create company" />
          </ListItem>
          <ListItem
            component={Link}
            to="/edit-account"
            onClick={toggleDrawer(false)}
          >
            <ListItemText primary="Edit account" />
          </ListItem>
          <ListItem component={Link} to="/users" onClick={toggleDrawer(false)}>
            <ListItemText primary="Users" />
          </ListItem>
          <ListItem component={Link} to="/users" onClick={toggleDrawer(false)}>
            <ListItemText primary="Users" />
          </ListItem>
          <ListItem
            component={Link}
            to="/login"
            onClick={() => {
              logoutUser();
            }}
          >
            <ListItemText primary="Logout" />
          </ListItem>
        </List>
      </Drawer>
    </div>
  );
};

export default LeftMenu;
