import React, { useEffect, useState } from "react";
import axios from "axios";
window.Buffer = window.Buffer || require("buffer").Buffer;

const FileDisplayComponent = (props: { filename: string }) => {
  const { filename } = props;
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    const fetchImage = async () => {
      try {
        const response = await axios.get(
          `http://localhost:5000/api/images/${filename}`,
          {
            responseType: "arraybuffer",
          }
        );

        const base64Image = Buffer.from(response.data, "binary").toString(
          "base64"
        );
        const imageDataUrl: string = `data:${response.headers["content-type"]};base64,${base64Image}`;
        setError("");
        setImageUrl(imageDataUrl);
      } catch (error: any) {
        setError(`Error fetching image`);
        console.error("Error fetching image:", error.message);
      }
    };

    fetchImage();
  }, [filename]);

  if (error) {
    return <>{error}</>;
  }
  return (
    <div>
      {imageUrl ? (
        <img
          src={imageUrl}
          alt="Image"
          style={{ maxWidth: "100%", maxHeight: "200px" }}
        />
      ) : (
        <p>Loading image...</p>
      )}
    </div>
  );
};

export default FileDisplayComponent;
