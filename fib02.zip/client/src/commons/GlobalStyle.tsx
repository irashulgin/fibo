import styled from "@emotion/styled";

export const GlobalStyledBox = styled.div`
  display: flex;
  flex-direction: column;
  align-items:baseline;
  align-items: center;
  gap: 1rem;
`;

export const StyledWithGap = styled.div`
display: flex; gap: 10px; 
`
