import React from "react";
import { Snackbar, Typography, Paper } from "@mui/material";

const ErrorDisplay = (props: { error: any; onClose: () => void }) => {
  const { error, onClose } = props;
  return (
    <Snackbar
      open={error !== null}
      autoHideDuration={6000} 
      onClose={onClose}
    >
      <Paper
        elevation={3}
        style={{
          padding: "15px",
          backgroundColor: "#f44336",
          color: "#fff",
          borderRadius: "5px",
        }}
      >
        <Typography variant="body1">
          <strong>Error:</strong>{" "}
          {error?.message || "An unexpected error occurred."}
        </Typography>
      </Paper>
    </Snackbar>
  );
};

export default ErrorDisplay;
