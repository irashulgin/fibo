import * as React from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { error } from "console";

export default function FormDialog(props: {
  email: string;
  message: string;
  setEmail: (email: string) => void;
  handleReset: () => void;
}) {
  const [open, setOpen] = React.useState(false);
  const { email, setEmail, handleReset } = props;

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <React.Fragment>
      <Button variant="outlined" onClick={handleClickOpen}>
        Reset password
      </Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Subscribe</DialogTitle>
        <DialogContent>
          <DialogContentText>
            To reset password, please enter your email address here. We will
            send you an email.
          </DialogContentText>
          <DialogContentText>{props.message}</DialogContentText>
          <>
            {" "}
            <TextField
              autoFocus
              margin="dense"
              id="name"
              label="Email Address"
              type="email"
              fullWidth
              variant="standard"
              placeholder={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            {/* {error} */}
          </>
        </DialogContent>

        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleReset}>Reset</Button>
        </DialogActions>
      </Dialog>
    </React.Fragment>
  );
}
