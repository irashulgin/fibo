import { Box, Typography } from "@mui/material";

const ThanksPage = (props: { title: string; text: string; footer: string }) => {
  const { text, title, footer } = props;
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        gap: "1rem",
        marginTop: "1rem",
      }}
    >
      <Typography sx={{ whiteSpace: "pre-line", flex: 1, fontSize: "20px" }}>
        {title}
      </Typography>

      <Typography sx={{ whiteSpace: "pre-line", flex: 1, fontSize: "16px" }}>
        {text}
      </Typography>
      <Typography sx={{ whiteSpace: "pre-line", flex: 1, fontSize: "16px" }}>
        {footer}
      </Typography>
    </Box>
  );
};
export default ThanksPage;
