import styled from '@emotion/styled'

const Button = styled.button`
  color: #000;
  width:6.25rem;
  height:2.5rem;
  border:1px solid #000;
`

type MyFunctionType = {onClick : () => void, type?: "button" | "submit" | "reset" | undefined};

const PrevButton = (props:MyFunctionType) => {
    const {onClick, type} = props; 

    return (
        <Button onClick={onClick} type={type}>{`<< Prev`}</Button>
    )
}
export default PrevButton;