

export function validatePassword(password: string) {
  const minLength = 8;
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumber = /\d/.test(password);
  const hasSpecialChar = /[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test(password);
  const noCommonWords = !/(password|123456|qwerty|admin)/i.test(password);
  // const noSequentialChars = !/(123|abc|qwerty)/i.test(password);
  // const noRepeatedChars = !/(.)\1{2,}/.test(password);

  return (
    password.length >= minLength &&
    hasUppercase &&
    hasLowercase &&
    hasNumber &&
    hasSpecialChar &&
    noCommonWords
    // noSequentialChars &&
    // noRepeatedChars
  );
}
export function validateEmail(email: string) {
  // Regular expression for a basic email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}


// export const API_STATUS = {
//   SUCCESS: 200,
// };

export enum HttpStatusCode {
  OK = 200,
  NotFound = 404,
  InternalServerError = 500,
}