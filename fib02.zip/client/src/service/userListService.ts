import { AxiosResponse } from "axios";
import api  from "../http";
import { IUser } from "../models/IUser";

export default class UserListService {
  static fetchUsers(searchTerm: string): Promise<AxiosResponse<IUser[]>> {
    return api.get<IUser[]>(`/users?search=${searchTerm}`);
  }
 
  // static async upload(selectedFile:File){
  //   const formData = new FormData();
  //   formData.append('file', selectedFile);
  //   return api.post("/upload", formData);
  // }
}
