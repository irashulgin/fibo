import { AxiosResponse } from "axios";
import api from "../http";
 import { IEvent } from "../models/IEvent";

export default class EventService {
  static async createCompany(
    event: IEvent
  ): Promise<AxiosResponse<IEvent>> {
    return api.post<IEvent>(`/create-event`, { ...event });
  }
 
}
