import { AxiosResponse } from "axios";
import api from "../http";
import { IUser } from "../models/IUser";
import { AuthResponse, ImgResponse } from "../models/response/AuthResponse";

export default class UserService {
  static async collect(userInfo: IUser) {
    return api.post("/collect", { ...userInfo });
  }

  static async inviteUser(
    email: string,
    user?: string,
    note?: string
  ): Promise<AxiosResponse<AuthResponse>> {
    return api.post<AuthResponse>("/send-invitation", { email, user, note });
  }
  static async upload(
    email: string,
    selectedFile: File
  ): Promise<AxiosResponse<ImgResponse>> {
    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("email", email);
    return api.post<ImgResponse>("/upload", formData);
  }

  // static async upload(selectedFile:File){
  //   const formData = new FormData();
  //   formData.append('file', selectedFile);
  //   return api.post("/upload", formData);
  // }
}
