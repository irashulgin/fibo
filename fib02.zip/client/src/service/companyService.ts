import { AxiosResponse } from "axios";
import api from "../http";
import { ICompany } from "../models/ICompany";

export default class CompanyService {
  static async createCompany(
    company: ICompany
  ): Promise<AxiosResponse<ICompany>> {
    return api.post<ICompany>(`/create-company`, { ...company });
  }

  // static async uploadCompany(
  //   email: string,
  //   selectedFile: File
  // ): Promise<AxiosResponse<ImgResponse>> {
  //   const formData = new FormData();
  //   formData.append("file", selectedFile);
  //   formData.append("email", email);
  //   return api.post<ImgResponse>("/upload-company", formData);
  // }
}
