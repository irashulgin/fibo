import { AxiosResponse } from "axios";
import api from "../http";
import { AuthResponse } from "../models/response/AuthResponse";
import { IUser } from "../models/IUser";

export default class AuthService {
  static async login(
    email: string,
    password: string
  ): Promise<AxiosResponse<AuthResponse>> {
    return api.post<AuthResponse>("/login", { email, password });
  }
  static async registration(userInfo: IUser) {
    return api.post<AuthResponse>("/registration", { ...userInfo });
  }

  static async logout(): Promise<void> {
    return api.post("/logout");
  }

  static async forgotPassword(
    email: string
  ): Promise<AxiosResponse<AuthResponse>> {
    return api.post<AuthResponse>("/forgot-password", { email });
  }

  static async resetPassword(
    token: string,
    password: string
  ): Promise<AxiosResponse<AuthResponse>> {
    return api.post<AuthResponse>("/reset-password", { token, password });
  }

  static async checkReference(
    reference: number
  ): Promise<AxiosResponse<AuthResponse>> {
    return api.post<AuthResponse>("/check-reference", { reference });
  }
}
