import { AxiosResponse } from "axios";
import api from "../http";
import { IChallenge } from "../models/IChallenge";
import { ImgResponse } from "../models/response/AuthResponse";

export default class ChallengeService {
  static async addNewChallenge(
    challenge: IChallenge
  ): Promise<AxiosResponse<IChallenge>> {
    return api.post<IChallenge>(`/add-challenge`, { ...challenge });
  }
  static fetchChallenges(
    searchTerm: string,
    email: string
  ): Promise<AxiosResponse<IChallenge[]>> {
    return api.get<IChallenge[]>(
      `/challenges?search=${searchTerm}&email=${email}`
    );
  }
  static async uploadCompany(
    email: string,
    selectedFile: File
  ): Promise<AxiosResponse<ImgResponse>> {
    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("email", email);
    return api.post<ImgResponse>("/upload-company", formData);
  }
}
