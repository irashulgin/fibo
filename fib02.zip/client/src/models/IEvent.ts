import { IUser } from "./IUser";

export interface IEvent {
  description: string;
  creator: IUser;
  place: string;
  date: string;
}
