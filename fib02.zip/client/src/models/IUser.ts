export interface IUser {
  email: string;
  id?: string;
  isActivated?: boolean;
  name: string;
  lastName: string;
  profession?: string;
  phone?: number | null;
  birthDate?: Date;
  currentWork?: string;
  institute?:string;
  city?: string;
  password: string;
  reference?: number | null;
  role: string;
  interests?: string;
  about?: string;
  imageUrl?: string;
  company?: string;
  rewards?: string[];
  challenges?: string[]; //ids of challenges
}
export interface IAdmin {}
export interface ISuperAdmin {}
