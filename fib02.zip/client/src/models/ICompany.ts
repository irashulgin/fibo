import { IUser } from "./IUser";

export interface ICompany {
  description: string;
  _id: string;
  city:string;
  tags:string[];
  email:IUser;
  logo:string;
  name:string;
  industry:string;
  type:string;
}
