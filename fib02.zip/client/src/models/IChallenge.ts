import { IUser } from "./IUser";

export interface IChallenge {
  description: string;
  _id: string;
  done: boolean;
  creator: IUser;
  imageUrl: string;
  price: string;
  firstPlace: string;
  secondPlace: string;
  thirdPlace: string;
  startDate: string;
  lastRegisterDate: string;
  roundname: string;
  endDate: string;
  primary: string;
  secondary: string;
  profession: string;
  level: string;
  industry: string;
  methodology: string;
  tool: string;
  points: string;
  fileDescription: string;
  fileTitle: string;
  rules: string;
  roundsData: {
    roundName: string;
    roundDate: string;
  }[];
}
