 import { ReactComponent as MyIcon } from './Ellipse2.svg';
 export function Icon(){return <MyIcon />}
// export const SVGbackground = ()=>{
//     return(
//     <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" width="192" height="192" viewBox="0 0 192 192" fill="none">
// <circle cx="96" cy="96" r="96" fill="url(#pattern0)" fill-opacity="0.8"/>
// <defs>
// <pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">
// <use href="#image0_1_99" transform="scale(0.015625)"/>
// </pattern>
// <image id="image0_1_99" width="64" height="64" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAANpJREFUeF7t2sENxCAMBVHTa0qgjJSwvW6KmAMHXu6RJYhnPiZrZv4Tnmfv8PbM733T+7X+sgC+AC2AAYVCFUIgyAI0WDpwagvKAYKQICQICUIFw5XCgtDpIPTsnVrg9A7W+ssC+AK0AAYUDVYIndYoCLIAC7AAC7BAWAEaPHyaqxsgB1yfA0yFTYVNhVMQOn2aq/VdjYEgCIIgCIazUP5BoWZ5Foh/qtIgDdIgDd6twesHIhbAzZCboQTB01G21jcWB0EQBEEQLAORSuE60Kj1WYAFWIAFrrbAB3sgiZAN1tubAAAAAElFTkSuQmCC"/>
// </defs>
// </svg>
// )}
// import { Box, SvgIcon, SvgIconProps } from "@mui/material";

// export interface IconProps extends SvgIconProps {}

// const Icon = (props: IconProps) => {
//   return (
//     <SvgIcon {...props}><path d="M0 0h24v24H0V0Z"/></SvgIcon>
//   );
// };

// export default Icon;